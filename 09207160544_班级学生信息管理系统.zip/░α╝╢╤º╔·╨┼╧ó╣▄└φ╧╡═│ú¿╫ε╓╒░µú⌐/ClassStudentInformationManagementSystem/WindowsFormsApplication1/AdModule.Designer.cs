﻿namespace WindowsFormsApplication1
{
    partial class AdministratorModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdministratorModule));
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.FeeRewPun = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.OpenFileDia = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.LoadTips6 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txtSnoFRP = new System.Windows.Forms.TextBox();
            this.btnAlterFRP = new System.Windows.Forms.Button();
            this.btnSelectFRP = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnClear2 = new System.Windows.Forms.Button();
            this.btnCount2 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtSnoSC = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnClear1 = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtClassSC = new System.Windows.Forms.TextBox();
            this.txtGradeSC = new System.Windows.Forms.TextBox();
            this.txtObjSC = new System.Windows.Forms.TextBox();
            this.btnCount1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.班级统计 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.importScore = new System.Windows.Forms.Button();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.openFile = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.txtCno = new System.Windows.Forms.TextBox();
            this.txtSno = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.addORalter = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.LoadTips4 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.AddCourseDis = new System.Windows.Forms.Button();
            this.txtCgrade = new System.Windows.Forms.TextBox();
            this.txtCmajor = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.txtCno2 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.LoadTips3 = new System.Windows.Forms.Label();
            this.AddCourse = new System.Windows.Forms.Button();
            this.txtCno1 = new System.Windows.Forms.TextBox();
            this.txtCname = new System.Windows.Forms.TextBox();
            this.txtCtecher = new System.Windows.Forms.TextBox();
            this.txtCredit = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.AlterCourse = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.ExportCourse = new System.Windows.Forms.Button();
            this.txtCno3 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.LoadTips5 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.SelectCourse = new System.Windows.Forms.Button();
            this.ImportCourse = new System.Windows.Forms.Button();
            this.OpenFileDia2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.LoadTips2 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.Glade = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.StudentId1 = new System.Windows.Forms.TextBox();
            this.MobilePhoneNum = new System.Windows.Forms.TextBox();
            this.DormPhoneNum = new System.Windows.Forms.TextBox();
            this.HomePhoneNum = new System.Windows.Forms.TextBox();
            this.DormAddr = new System.Windows.Forms.TextBox();
            this.PostalCode = new System.Windows.Forms.TextBox();
            this.NowFamAddr = new System.Windows.Forms.TextBox();
            this.FamilyAddr = new System.Windows.Forms.TextBox();
            this.ShengYuanD = new System.Windows.Forms.TextBox();
            this.ExamineID = new System.Windows.Forms.TextBox();
            this.IDNumber = new System.Windows.Forms.TextBox();
            this.Birthdate = new System.Windows.Forms.TextBox();
            this.StudentId2 = new System.Windows.Forms.TextBox();
            this.JiGuan = new System.Windows.Forms.TextBox();
            this.MingZhu = new System.Windows.Forms.TextBox();
            this.XueZhi = new System.Windows.Forms.TextBox();
            this.EntryTime = new System.Windows.Forms.TextBox();
            this.StudentCatogary = new System.Windows.Forms.TextBox();
            this.Class = new System.Windows.Forms.TextBox();
            this.Professal = new System.Windows.Forms.TextBox();
            this.Academy = new System.Windows.Forms.TextBox();
            this.School = new System.Windows.Forms.TextBox();
            this.UsedName = new System.Windows.Forms.TextBox();
            this.Sex = new System.Windows.Forms.TextBox();
            this.StudentName = new System.Windows.Forms.TextBox();
            this.ZhengZhiMM = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.LoadTips1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.UserName = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.Pwd = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.ImportXL = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.OpenFileDialog = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.LoadTips7 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.AlterXL = new System.Windows.Forms.Button();
            this.SelectXL = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.UsedPwd = new System.Windows.Forms.TextBox();
            this.NewPwd = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.SureNewPwd = new System.Windows.Forms.TextBox();
            this.LoadTips8 = new System.Windows.Forms.Label();
            this.tabPage8.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.班级统计.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.linkLabel1);
            this.tabPage8.Controls.Add(this.groupBox5);
            this.tabPage8.Controls.Add(this.FeeRewPun);
            this.tabPage8.Controls.Add(this.textBox1);
            this.tabPage8.Controls.Add(this.OpenFileDia);
            this.tabPage8.Controls.Add(this.groupBox6);
            this.tabPage8.Controls.Add(this.dataGridView2);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(860, 481);
            this.tabPage8.TabIndex = 9;
            this.tabPage8.Text = "学费奖惩管理";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel1.Location = new System.Drawing.Point(10, 12);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(126, 14);
            this.linkLabel1.TabIndex = 34;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Excel文件格式说明";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.ForeColor = System.Drawing.Color.Gray;
            this.groupBox5.Location = new System.Drawing.Point(613, 249);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(241, 225);
            this.groupBox5.TabIndex = 26;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "错误列表";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(6, 13);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(229, 208);
            this.listBox1.TabIndex = 0;
            // 
            // FeeRewPun
            // 
            this.FeeRewPun.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.FeeRewPun.Location = new System.Drawing.Point(744, 7);
            this.FeeRewPun.Name = "FeeRewPun";
            this.FeeRewPun.Size = new System.Drawing.Size(102, 26);
            this.FeeRewPun.TabIndex = 25;
            this.FeeRewPun.Text = "学费奖惩导入";
            this.FeeRewPun.UseVisualStyleBackColor = true;
            this.FeeRewPun.Click += new System.EventHandler(this.FeeRewPun_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(140, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(465, 21);
            this.textBox1.TabIndex = 24;
            // 
            // OpenFileDia
            // 
            this.OpenFileDia.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.OpenFileDia.Location = new System.Drawing.Point(621, 7);
            this.OpenFileDia.Name = "OpenFileDia";
            this.OpenFileDia.Size = new System.Drawing.Size(102, 27);
            this.OpenFileDia.TabIndex = 23;
            this.OpenFileDia.Text = "浏览Excel文件";
            this.OpenFileDia.UseVisualStyleBackColor = true;
            this.OpenFileDia.Click += new System.EventHandler(this.openFileDia_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.LoadTips6);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.txtSnoFRP);
            this.groupBox6.Controls.Add(this.btnAlterFRP);
            this.groupBox6.Controls.Add(this.btnSelectFRP);
            this.groupBox6.ForeColor = System.Drawing.Color.Gray;
            this.groupBox6.Location = new System.Drawing.Point(613, 43);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(241, 199);
            this.groupBox6.TabIndex = 22;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "个人查询修改";
            // 
            // LoadTips6
            // 
            this.LoadTips6.AutoSize = true;
            this.LoadTips6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips6.ForeColor = System.Drawing.Color.Red;
            this.LoadTips6.Location = new System.Drawing.Point(19, 24);
            this.LoadTips6.Name = "LoadTips6";
            this.LoadTips6.Size = new System.Drawing.Size(64, 16);
            this.LoadTips6.TabIndex = 8;
            this.LoadTips6.Text = "label69";
            this.LoadTips6.Visible = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.BlueViolet;
            this.label35.Location = new System.Drawing.Point(10, 64);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 12);
            this.label35.TabIndex = 1;
            this.label35.Text = "学 号：";
            // 
            // txtSnoFRP
            // 
            this.txtSnoFRP.Location = new System.Drawing.Point(58, 60);
            this.txtSnoFRP.Name = "txtSnoFRP";
            this.txtSnoFRP.Size = new System.Drawing.Size(168, 21);
            this.txtSnoFRP.TabIndex = 2;
            // 
            // btnAlterFRP
            // 
            this.btnAlterFRP.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnAlterFRP.Location = new System.Drawing.Point(125, 131);
            this.btnAlterFRP.Name = "btnAlterFRP";
            this.btnAlterFRP.Size = new System.Drawing.Size(101, 34);
            this.btnAlterFRP.TabIndex = 7;
            this.btnAlterFRP.Text = "修 改";
            this.btnAlterFRP.UseVisualStyleBackColor = true;
            this.btnAlterFRP.Click += new System.EventHandler(this.btnAlterFRP_Click);
            // 
            // btnSelectFRP
            // 
            this.btnSelectFRP.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnSelectFRP.Location = new System.Drawing.Point(18, 131);
            this.btnSelectFRP.Name = "btnSelectFRP";
            this.btnSelectFRP.Size = new System.Drawing.Size(101, 34);
            this.btnSelectFRP.TabIndex = 4;
            this.btnSelectFRP.Text = "查 询";
            this.btnSelectFRP.UseVisualStyleBackColor = true;
            this.btnSelectFRP.Click += new System.EventHandler(this.btnSelectFRP_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 37);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(601, 437);
            this.dataGridView2.TabIndex = 20;
            this.dataGridView2.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellValueChanged);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox3);
            this.tabPage6.Controls.Add(this.groupBox2);
            this.tabPage6.Controls.Add(this.dataGridView4);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(860, 481);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "成绩统计";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnClear2);
            this.groupBox3.Controls.Add(this.btnCount2);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.txtSnoSC);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.ForeColor = System.Drawing.Color.Gray;
            this.groupBox3.Location = new System.Drawing.Point(518, 265);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(336, 213);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "个人统计";
            // 
            // btnClear2
            // 
            this.btnClear2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnClear2.Location = new System.Drawing.Point(174, 158);
            this.btnClear2.Name = "btnClear2";
            this.btnClear2.Size = new System.Drawing.Size(108, 31);
            this.btnClear2.TabIndex = 18;
            this.btnClear2.Text = "重  置";
            this.btnClear2.UseVisualStyleBackColor = true;
            this.btnClear2.Click += new System.EventHandler(this.btnClear2_Click);
            // 
            // btnCount2
            // 
            this.btnCount2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnCount2.Location = new System.Drawing.Point(57, 158);
            this.btnCount2.Name = "btnCount2";
            this.btnCount2.Size = new System.Drawing.Size(108, 31);
            this.btnCount2.TabIndex = 17;
            this.btnCount2.Text = " 统  计";
            this.btnCount2.UseVisualStyleBackColor = true;
            this.btnCount2.Click += new System.EventHandler(this.btnCount2_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "2009-2010学年第一学期",
            "2009-2010学年第二学期",
            "2010-2011学年第一学期",
            "2010-2011学年第二学期",
            "2011-2012学年第一学期",
            "2011-2012学年第二学期",
            "2012-2013学年第一学期",
            "2012-2013学年第二学期"});
            this.comboBox2.Location = new System.Drawing.Point(102, 44);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(180, 20);
            this.comboBox2.TabIndex = 16;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.ForeColor = System.Drawing.Color.BlueViolet;
            this.label38.Location = new System.Drawing.Point(55, 47);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(53, 12);
            this.label38.TabIndex = 15;
            this.label38.Text = "学  期：";
            // 
            // txtSnoSC
            // 
            this.txtSnoSC.Location = new System.Drawing.Point(102, 98);
            this.txtSnoSC.Name = "txtSnoSC";
            this.txtSnoSC.Size = new System.Drawing.Size(180, 21);
            this.txtSnoSC.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.BlueViolet;
            this.label8.Location = new System.Drawing.Point(55, 104);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "学  号：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnClear1);
            this.groupBox2.Controls.Add(this.btnExport);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtClassSC);
            this.groupBox2.Controls.Add(this.txtGradeSC);
            this.groupBox2.Controls.Add(this.txtObjSC);
            this.groupBox2.Controls.Add(this.btnCount1);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.ForeColor = System.Drawing.Color.Gray;
            this.groupBox2.Location = new System.Drawing.Point(518, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(336, 263);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "班级统计";
            // 
            // btnClear1
            // 
            this.btnClear1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnClear1.Location = new System.Drawing.Point(129, 198);
            this.btnClear1.Name = "btnClear1";
            this.btnClear1.Size = new System.Drawing.Size(73, 32);
            this.btnClear1.TabIndex = 16;
            this.btnClear1.Text = "重 置";
            this.btnClear1.UseVisualStyleBackColor = true;
            this.btnClear1.Click += new System.EventHandler(this.btnClear1_Click);
            // 
            // btnExport
            // 
            this.btnExport.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnExport.Location = new System.Drawing.Point(208, 198);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(74, 32);
            this.btnExport.TabIndex = 15;
            this.btnExport.Text = "导 出";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2009-2010学年第一学期",
            "2009-2010学年第二学期",
            "2010-2011学年第一学期",
            "2010-2011学年第二学期",
            "2011-2012学年第一学期",
            "2011-2012学年第二学期",
            "2012-2013学年第一学期",
            "2012-2013学年第二学期"});
            this.comboBox1.Location = new System.Drawing.Point(102, 31);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(180, 20);
            this.comboBox1.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.BlueViolet;
            this.label2.Location = new System.Drawing.Point(47, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "学  期：";
            // 
            // txtClassSC
            // 
            this.txtClassSC.Location = new System.Drawing.Point(102, 151);
            this.txtClassSC.Name = "txtClassSC";
            this.txtClassSC.Size = new System.Drawing.Size(180, 21);
            this.txtClassSC.TabIndex = 12;
            // 
            // txtGradeSC
            // 
            this.txtGradeSC.Location = new System.Drawing.Point(102, 111);
            this.txtGradeSC.Name = "txtGradeSC";
            this.txtGradeSC.Size = new System.Drawing.Size(180, 21);
            this.txtGradeSC.TabIndex = 11;
            // 
            // txtObjSC
            // 
            this.txtObjSC.Location = new System.Drawing.Point(102, 70);
            this.txtObjSC.Name = "txtObjSC";
            this.txtObjSC.Size = new System.Drawing.Size(180, 21);
            this.txtObjSC.TabIndex = 10;
            // 
            // btnCount1
            // 
            this.btnCount1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnCount1.Location = new System.Drawing.Point(48, 198);
            this.btnCount1.Name = "btnCount1";
            this.btnCount1.Size = new System.Drawing.Size(74, 32);
            this.btnCount1.TabIndex = 9;
            this.btnCount1.Text = " 统 计";
            this.btnCount1.UseVisualStyleBackColor = true;
            this.btnCount1.Click += new System.EventHandler(this.btnCount1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.BlueViolet;
            this.label7.Location = new System.Drawing.Point(47, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "班  别：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.BlueViolet;
            this.label6.Location = new System.Drawing.Point(46, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "年  级：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.BlueViolet;
            this.label5.Location = new System.Drawing.Point(47, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "专  业：";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(3, 6);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(503, 472);
            this.dataGridView4.TabIndex = 16;
            // 
            // 班级统计
            // 
            this.班级统计.AllowDrop = true;
            this.班级统计.Controls.Add(this.groupBox9);
            this.班级统计.Controls.Add(this.groupBox8);
            this.班级统计.Controls.Add(this.importScore);
            this.班级统计.Controls.Add(this.txtPath);
            this.班级统计.Controls.Add(this.openFile);
            this.班级统计.Controls.Add(this.groupBox1);
            this.班级统计.Controls.Add(this.dataGridView3);
            this.班级统计.Location = new System.Drawing.Point(4, 22);
            this.班级统计.Name = "班级统计";
            this.班级统计.Padding = new System.Windows.Forms.Padding(3);
            this.班级统计.Size = new System.Drawing.Size(860, 481);
            this.班级统计.TabIndex = 4;
            this.班级统计.Text = "成绩录入修改";
            this.班级统计.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.pictureBox2);
            this.groupBox9.ForeColor = System.Drawing.Color.Gray;
            this.groupBox9.Location = new System.Drawing.Point(347, 331);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(264, 144);
            this.groupBox9.TabIndex = 22;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "表格格式说明";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApplication1.Properties.Resources.格式说明;
            this.pictureBox2.Location = new System.Drawing.Point(6, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(252, 108);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.listBox2);
            this.groupBox8.ForeColor = System.Drawing.Color.Gray;
            this.groupBox8.Location = new System.Drawing.Point(6, 328);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(329, 147);
            this.groupBox8.TabIndex = 21;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "错误列表";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.HorizontalScrollbar = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(6, 15);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(317, 124);
            this.listBox2.TabIndex = 0;
            // 
            // importScore
            // 
            this.importScore.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.importScore.Location = new System.Drawing.Point(744, 3);
            this.importScore.Name = "importScore";
            this.importScore.Size = new System.Drawing.Size(102, 25);
            this.importScore.TabIndex = 18;
            this.importScore.Text = "成绩批量导入";
            this.importScore.UseVisualStyleBackColor = true;
            this.importScore.Click += new System.EventHandler(this.importScore_Click);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(6, 5);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(605, 21);
            this.txtPath.TabIndex = 17;
            // 
            // openFile
            // 
            this.openFile.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.openFile.Location = new System.Drawing.Point(629, 3);
            this.openFile.Name = "openFile";
            this.openFile.Size = new System.Drawing.Size(102, 25);
            this.openFile.TabIndex = 1;
            this.openFile.Text = "浏览Excel文件";
            this.openFile.UseVisualStyleBackColor = true;
            this.openFile.Click += new System.EventHandler(this.openFile_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtScore);
            this.groupBox1.Controls.Add(this.txtCno);
            this.groupBox1.Controls.Add(this.txtSno);
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.addORalter);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.Color.Gray;
            this.groupBox1.Location = new System.Drawing.Point(617, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(237, 441);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "添加/查询/修改";
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(69, 202);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(160, 21);
            this.txtScore.TabIndex = 25;
            // 
            // txtCno
            // 
            this.txtCno.Location = new System.Drawing.Point(69, 132);
            this.txtCno.Name = "txtCno";
            this.txtCno.Size = new System.Drawing.Size(160, 21);
            this.txtCno.TabIndex = 24;
            this.txtCno.TextChanged += new System.EventHandler(this.Cno_TextChanged);
            // 
            // txtSno
            // 
            this.txtSno.Location = new System.Drawing.Point(69, 59);
            this.txtSno.Name = "txtSno";
            this.txtSno.Size = new System.Drawing.Size(160, 21);
            this.txtSno.TabIndex = 22;
            this.txtSno.TextChanged += new System.EventHandler(this.Sno_TextChanged);
            // 
            // btnClear
            // 
            this.btnClear.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnClear.Location = new System.Drawing.Point(46, 357);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(148, 37);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "重  置";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // addORalter
            // 
            this.addORalter.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.addORalter.Location = new System.Drawing.Point(46, 274);
            this.addORalter.Name = "addORalter";
            this.addORalter.Size = new System.Drawing.Size(148, 37);
            this.addORalter.TabIndex = 20;
            this.addORalter.Text = "添加/修改";
            this.addORalter.UseVisualStyleBackColor = true;
            this.addORalter.Click += new System.EventHandler(this.addORalter_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.BlueViolet;
            this.label4.Location = new System.Drawing.Point(10, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = " 成   绩：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.BlueViolet;
            this.label3.Location = new System.Drawing.Point(10, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "课 程 号：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.BlueViolet;
            this.label1.Location = new System.Drawing.Point(10, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 16;
            this.label1.Text = " 学   号：";
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(6, 32);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(605, 293);
            this.dataGridView3.TabIndex = 15;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.linkLabel3);
            this.tabPage4.Controls.Add(this.groupBox14);
            this.tabPage4.Controls.Add(this.groupBox13);
            this.tabPage4.Controls.Add(this.dataGridView6);
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox12);
            this.tabPage4.Controls.Add(this.ImportCourse);
            this.tabPage4.Controls.Add(this.OpenFileDia2);
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(860, 481);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "课程表管理";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel3.Location = new System.Drawing.Point(6, 7);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(126, 14);
            this.linkLabel3.TabIndex = 120;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Excel文件格式说明";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.listBox4);
            this.groupBox14.ForeColor = System.Drawing.Color.Gray;
            this.groupBox14.Location = new System.Drawing.Point(6, 289);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(307, 186);
            this.groupBox14.TabIndex = 119;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "错误列表";
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.HorizontalScrollbar = true;
            this.listBox4.ItemHeight = 12;
            this.listBox4.Location = new System.Drawing.Point(6, 17);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(295, 160);
            this.listBox4.TabIndex = 0;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.LoadTips4);
            this.groupBox13.Controls.Add(this.comboBox5);
            this.groupBox13.Controls.Add(this.AddCourseDis);
            this.groupBox13.Controls.Add(this.txtCgrade);
            this.groupBox13.Controls.Add(this.txtCmajor);
            this.groupBox13.Controls.Add(this.label77);
            this.groupBox13.Controls.Add(this.label73);
            this.groupBox13.Controls.Add(this.label69);
            this.groupBox13.Controls.Add(this.txtCno2);
            this.groupBox13.Controls.Add(this.label83);
            this.groupBox13.ForeColor = System.Drawing.Color.Gray;
            this.groupBox13.Location = new System.Drawing.Point(594, 289);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(260, 186);
            this.groupBox13.TabIndex = 118;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "课程分配";
            // 
            // LoadTips4
            // 
            this.LoadTips4.AutoSize = true;
            this.LoadTips4.ForeColor = System.Drawing.Color.Red;
            this.LoadTips4.Location = new System.Drawing.Point(30, 20);
            this.LoadTips4.Name = "LoadTips4";
            this.LoadTips4.Size = new System.Drawing.Size(47, 12);
            this.LoadTips4.TabIndex = 93;
            this.LoadTips4.Text = "label76";
            this.LoadTips4.Visible = false;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "2009-2010学年第一学期",
            "2009-2010学年第二学期",
            "2010-2011学年第一学期",
            "2010-2011学年第二学期",
            "2011-2012学年第一学期",
            "2011-2012学年第二学期",
            "2012-2013学年第一学期",
            "2012-2013学年第二学期"});
            this.comboBox5.Location = new System.Drawing.Point(90, 121);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(139, 20);
            this.comboBox5.TabIndex = 92;
            // 
            // AddCourseDis
            // 
            this.AddCourseDis.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AddCourseDis.Location = new System.Drawing.Point(33, 149);
            this.AddCourseDis.Name = "AddCourseDis";
            this.AddCourseDis.Size = new System.Drawing.Size(196, 29);
            this.AddCourseDis.TabIndex = 91;
            this.AddCourseDis.Text = "分  配";
            this.AddCourseDis.UseVisualStyleBackColor = true;
            this.AddCourseDis.Click += new System.EventHandler(this.AddCourseDis_Click);
            // 
            // txtCgrade
            // 
            this.txtCgrade.Location = new System.Drawing.Point(90, 94);
            this.txtCgrade.Name = "txtCgrade";
            this.txtCgrade.Size = new System.Drawing.Size(139, 21);
            this.txtCgrade.TabIndex = 90;
            // 
            // txtCmajor
            // 
            this.txtCmajor.Location = new System.Drawing.Point(90, 66);
            this.txtCmajor.Name = "txtCmajor";
            this.txtCmajor.Size = new System.Drawing.Size(139, 21);
            this.txtCmajor.TabIndex = 89;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.ForeColor = System.Drawing.Color.BlueViolet;
            this.label77.Location = new System.Drawing.Point(35, 98);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(53, 12);
            this.label77.TabIndex = 88;
            this.label77.Text = "年  级：";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.ForeColor = System.Drawing.Color.BlueViolet;
            this.label73.Location = new System.Drawing.Point(34, 70);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(53, 12);
            this.label73.TabIndex = 87;
            this.label73.Text = "专  业：";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.ForeColor = System.Drawing.Color.BlueViolet;
            this.label69.Location = new System.Drawing.Point(34, 124);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(53, 12);
            this.label69.TabIndex = 85;
            this.label69.Text = "学  期：";
            // 
            // txtCno2
            // 
            this.txtCno2.Location = new System.Drawing.Point(90, 38);
            this.txtCno2.Name = "txtCno2";
            this.txtCno2.Size = new System.Drawing.Size(139, 21);
            this.txtCno2.TabIndex = 77;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.ForeColor = System.Drawing.Color.BlueViolet;
            this.label83.Location = new System.Drawing.Point(34, 43);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(53, 12);
            this.label83.TabIndex = 68;
            this.label83.Text = "课程号：";
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(4, 32);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.RowTemplate.Height = 23;
            this.dataGridView6.Size = new System.Drawing.Size(584, 251);
            this.dataGridView6.TabIndex = 117;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.LoadTips3);
            this.groupBox11.Controls.Add(this.AddCourse);
            this.groupBox11.Controls.Add(this.txtCno1);
            this.groupBox11.Controls.Add(this.txtCname);
            this.groupBox11.Controls.Add(this.txtCtecher);
            this.groupBox11.Controls.Add(this.txtCredit);
            this.groupBox11.Controls.Add(this.label68);
            this.groupBox11.Controls.Add(this.label70);
            this.groupBox11.Controls.Add(this.label71);
            this.groupBox11.Controls.Add(this.AlterCourse);
            this.groupBox11.Controls.Add(this.label72);
            this.groupBox11.ForeColor = System.Drawing.Color.Gray;
            this.groupBox11.Location = new System.Drawing.Point(594, 32);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(260, 251);
            this.groupBox11.TabIndex = 116;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "课程添加/修改";
            // 
            // LoadTips3
            // 
            this.LoadTips3.AutoSize = true;
            this.LoadTips3.ForeColor = System.Drawing.Color.Red;
            this.LoadTips3.Location = new System.Drawing.Point(31, 22);
            this.LoadTips3.Name = "LoadTips3";
            this.LoadTips3.Size = new System.Drawing.Size(47, 12);
            this.LoadTips3.TabIndex = 94;
            this.LoadTips3.Text = "label78";
            this.LoadTips3.Visible = false;
            // 
            // AddCourse
            // 
            this.AddCourse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AddCourse.Location = new System.Drawing.Point(24, 193);
            this.AddCourse.Name = "AddCourse";
            this.AddCourse.Size = new System.Drawing.Size(103, 28);
            this.AddCourse.TabIndex = 84;
            this.AddCourse.Text = "添  加";
            this.AddCourse.UseVisualStyleBackColor = true;
            this.AddCourse.Click += new System.EventHandler(this.AddCourse_Click);
            // 
            // txtCno1
            // 
            this.txtCno1.Location = new System.Drawing.Point(97, 52);
            this.txtCno1.Name = "txtCno1";
            this.txtCno1.Size = new System.Drawing.Size(131, 21);
            this.txtCno1.TabIndex = 77;
            // 
            // txtCname
            // 
            this.txtCname.Location = new System.Drawing.Point(97, 84);
            this.txtCname.Name = "txtCname";
            this.txtCname.Size = new System.Drawing.Size(131, 21);
            this.txtCname.TabIndex = 76;
            // 
            // txtCtecher
            // 
            this.txtCtecher.AcceptsReturn = true;
            this.txtCtecher.Location = new System.Drawing.Point(97, 116);
            this.txtCtecher.Name = "txtCtecher";
            this.txtCtecher.Size = new System.Drawing.Size(131, 21);
            this.txtCtecher.TabIndex = 75;
            // 
            // txtCredit
            // 
            this.txtCredit.Location = new System.Drawing.Point(97, 149);
            this.txtCredit.Name = "txtCredit";
            this.txtCredit.Size = new System.Drawing.Size(131, 21);
            this.txtCredit.TabIndex = 74;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.ForeColor = System.Drawing.Color.BlueViolet;
            this.label68.Location = new System.Drawing.Point(30, 154);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(59, 12);
            this.label68.TabIndex = 72;
            this.label68.Text = " 学  分：";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.ForeColor = System.Drawing.Color.BlueViolet;
            this.label70.Location = new System.Drawing.Point(30, 120);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(65, 12);
            this.label70.TabIndex = 70;
            this.label70.Text = "授课教师：";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.ForeColor = System.Drawing.Color.BlueViolet;
            this.label71.Location = new System.Drawing.Point(30, 88);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(65, 12);
            this.label71.TabIndex = 69;
            this.label71.Text = "课 程 名：";
            // 
            // AlterCourse
            // 
            this.AlterCourse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AlterCourse.Location = new System.Drawing.Point(133, 193);
            this.AlterCourse.Name = "AlterCourse";
            this.AlterCourse.Size = new System.Drawing.Size(103, 28);
            this.AlterCourse.TabIndex = 83;
            this.AlterCourse.Text = "修  改";
            this.AlterCourse.UseVisualStyleBackColor = true;
            this.AlterCourse.Click += new System.EventHandler(this.AlterCourse_Click);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.ForeColor = System.Drawing.Color.BlueViolet;
            this.label72.Location = new System.Drawing.Point(30, 55);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(65, 12);
            this.label72.TabIndex = 68;
            this.label72.Text = "课 程 号：";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.ExportCourse);
            this.groupBox12.Controls.Add(this.txtCno3);
            this.groupBox12.Controls.Add(this.label74);
            this.groupBox12.Controls.Add(this.LoadTips5);
            this.groupBox12.Controls.Add(this.label75);
            this.groupBox12.Controls.Add(this.SelectCourse);
            this.groupBox12.ForeColor = System.Drawing.Color.Gray;
            this.groupBox12.Location = new System.Drawing.Point(319, 289);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(269, 186);
            this.groupBox12.TabIndex = 115;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "课程查询";
            // 
            // ExportCourse
            // 
            this.ExportCourse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.ExportCourse.Location = new System.Drawing.Point(137, 121);
            this.ExportCourse.Name = "ExportCourse";
            this.ExportCourse.Size = new System.Drawing.Size(117, 29);
            this.ExportCourse.TabIndex = 61;
            this.ExportCourse.Text = "导  出";
            this.ExportCourse.UseVisualStyleBackColor = true;
            this.ExportCourse.Click += new System.EventHandler(this.ExportCourse_Click);
            // 
            // txtCno3
            // 
            this.txtCno3.Location = new System.Drawing.Point(81, 64);
            this.txtCno3.Name = "txtCno3";
            this.txtCno3.Size = new System.Drawing.Size(165, 21);
            this.txtCno3.TabIndex = 59;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.ForeColor = System.Drawing.Color.BlueViolet;
            this.label74.Location = new System.Drawing.Point(12, 67);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(65, 12);
            this.label74.TabIndex = 57;
            this.label74.Text = "课 程 号：";
            // 
            // LoadTips5
            // 
            this.LoadTips5.AutoSize = true;
            this.LoadTips5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips5.ForeColor = System.Drawing.Color.Red;
            this.LoadTips5.Location = new System.Drawing.Point(78, 22);
            this.LoadTips5.Name = "LoadTips5";
            this.LoadTips5.Size = new System.Drawing.Size(64, 16);
            this.LoadTips5.TabIndex = 111;
            this.LoadTips5.Text = "label45";
            this.LoadTips5.Visible = false;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label75.Location = new System.Drawing.Point(7, 45);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(0, 12);
            this.label75.TabIndex = 56;
            // 
            // SelectCourse
            // 
            this.SelectCourse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SelectCourse.Location = new System.Drawing.Point(14, 121);
            this.SelectCourse.Name = "SelectCourse";
            this.SelectCourse.Size = new System.Drawing.Size(117, 29);
            this.SelectCourse.TabIndex = 67;
            this.SelectCourse.Text = "查  询";
            this.SelectCourse.UseVisualStyleBackColor = true;
            this.SelectCourse.Click += new System.EventHandler(this.SelectCourse_Click);
            // 
            // ImportCourse
            // 
            this.ImportCourse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.ImportCourse.Location = new System.Drawing.Point(735, 3);
            this.ImportCourse.Name = "ImportCourse";
            this.ImportCourse.Size = new System.Drawing.Size(113, 23);
            this.ImportCourse.TabIndex = 2;
            this.ImportCourse.Text = "课程批量导入";
            this.ImportCourse.UseVisualStyleBackColor = true;
            this.ImportCourse.Click += new System.EventHandler(this.ImportCourse_Click);
            // 
            // OpenFileDia2
            // 
            this.OpenFileDia2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.OpenFileDia2.Location = new System.Drawing.Point(598, 3);
            this.OpenFileDia2.Name = "OpenFileDia2";
            this.OpenFileDia2.Size = new System.Drawing.Size(123, 23);
            this.OpenFileDia2.TabIndex = 1;
            this.OpenFileDia2.Text = "浏览Excel文件";
            this.OpenFileDia2.UseVisualStyleBackColor = true;
            this.OpenFileDia2.Click += new System.EventHandler(this.OpenFileDia2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(136, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(450, 21);
            this.textBox2.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button9);
            this.tabPage2.Controls.Add(this.label66);
            this.tabPage2.Controls.Add(this.label65);
            this.tabPage2.Controls.Add(this.label64);
            this.tabPage2.Controls.Add(this.label63);
            this.tabPage2.Controls.Add(this.label62);
            this.tabPage2.Controls.Add(this.label61);
            this.tabPage2.Controls.Add(this.label60);
            this.tabPage2.Controls.Add(this.label59);
            this.tabPage2.Controls.Add(this.label58);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.label56);
            this.tabPage2.Controls.Add(this.label55);
            this.tabPage2.Controls.Add(this.label54);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Controls.Add(this.label52);
            this.tabPage2.Controls.Add(this.label51);
            this.tabPage2.Controls.Add(this.label50);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.label48);
            this.tabPage2.Controls.Add(this.label47);
            this.tabPage2.Controls.Add(this.label46);
            this.tabPage2.Controls.Add(this.label45);
            this.tabPage2.Controls.Add(this.label37);
            this.tabPage2.Controls.Add(this.LoadTips2);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.Glade);
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Controls.Add(this.StudentId1);
            this.tabPage2.Controls.Add(this.MobilePhoneNum);
            this.tabPage2.Controls.Add(this.DormPhoneNum);
            this.tabPage2.Controls.Add(this.HomePhoneNum);
            this.tabPage2.Controls.Add(this.DormAddr);
            this.tabPage2.Controls.Add(this.PostalCode);
            this.tabPage2.Controls.Add(this.NowFamAddr);
            this.tabPage2.Controls.Add(this.FamilyAddr);
            this.tabPage2.Controls.Add(this.ShengYuanD);
            this.tabPage2.Controls.Add(this.ExamineID);
            this.tabPage2.Controls.Add(this.IDNumber);
            this.tabPage2.Controls.Add(this.Birthdate);
            this.tabPage2.Controls.Add(this.StudentId2);
            this.tabPage2.Controls.Add(this.JiGuan);
            this.tabPage2.Controls.Add(this.MingZhu);
            this.tabPage2.Controls.Add(this.XueZhi);
            this.tabPage2.Controls.Add(this.EntryTime);
            this.tabPage2.Controls.Add(this.StudentCatogary);
            this.tabPage2.Controls.Add(this.Class);
            this.tabPage2.Controls.Add(this.Professal);
            this.tabPage2.Controls.Add(this.Academy);
            this.tabPage2.Controls.Add(this.School);
            this.tabPage2.Controls.Add(this.UsedName);
            this.tabPage2.Controls.Add(this.Sex);
            this.tabPage2.Controls.Add(this.StudentName);
            this.tabPage2.Controls.Add(this.ZhengZhiMM);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(860, 481);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "档案管理";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button9.Location = new System.Drawing.Point(658, 10);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(66, 23);
            this.button9.TabIndex = 126;
            this.button9.Text = "重 置";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button1_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.ForeColor = System.Drawing.Color.Red;
            this.label66.Location = new System.Drawing.Point(813, 115);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(17, 228);
            this.label66.TabIndex = 125;
            this.label66.Text = "标\r\n\r\n记\r\n\r\n为\r\n\r\n *\r\n\r\n的\r\n\r\n项\r\n\r\n不\r\n\r\n能\r\n\r\n为\r\n\r\n空";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.ForeColor = System.Drawing.Color.Fuchsia;
            this.label65.Location = new System.Drawing.Point(761, 453);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(11, 12);
            this.label65.TabIndex = 124;
            this.label65.Text = "*";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.ForeColor = System.Drawing.Color.Fuchsia;
            this.label64.Location = new System.Drawing.Point(761, 383);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(11, 12);
            this.label64.TabIndex = 123;
            this.label64.Text = "*";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.ForeColor = System.Drawing.Color.Fuchsia;
            this.label63.Location = new System.Drawing.Point(761, 346);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(11, 12);
            this.label63.TabIndex = 122;
            this.label63.Text = "*";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.ForeColor = System.Drawing.Color.Fuchsia;
            this.label62.Location = new System.Drawing.Point(761, 313);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(11, 12);
            this.label62.TabIndex = 121;
            this.label62.Text = "*";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.ForeColor = System.Drawing.Color.Fuchsia;
            this.label61.Location = new System.Drawing.Point(761, 279);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(11, 12);
            this.label61.TabIndex = 120;
            this.label61.Text = "*";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.ForeColor = System.Drawing.Color.Fuchsia;
            this.label60.Location = new System.Drawing.Point(760, 245);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(11, 12);
            this.label60.TabIndex = 119;
            this.label60.Text = "*";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.ForeColor = System.Drawing.Color.Fuchsia;
            this.label59.Location = new System.Drawing.Point(762, 212);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(11, 12);
            this.label59.TabIndex = 118;
            this.label59.Text = "*";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.ForeColor = System.Drawing.Color.Fuchsia;
            this.label58.Location = new System.Drawing.Point(763, 177);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(11, 12);
            this.label58.TabIndex = 117;
            this.label58.Text = "*";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.ForeColor = System.Drawing.Color.Fuchsia;
            this.label57.Location = new System.Drawing.Point(762, 142);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(11, 12);
            this.label57.TabIndex = 116;
            this.label57.Text = "*";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.ForeColor = System.Drawing.Color.Fuchsia;
            this.label56.Location = new System.Drawing.Point(762, 50);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(11, 12);
            this.label56.TabIndex = 115;
            this.label56.Text = "*";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.ForeColor = System.Drawing.Color.Fuchsia;
            this.label55.Location = new System.Drawing.Point(368, 453);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(11, 12);
            this.label55.TabIndex = 114;
            this.label55.Text = "*";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.ForeColor = System.Drawing.Color.Fuchsia;
            this.label54.Location = new System.Drawing.Point(368, 419);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(11, 12);
            this.label54.TabIndex = 113;
            this.label54.Text = "*";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.Color.Fuchsia;
            this.label53.Location = new System.Drawing.Point(368, 383);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(11, 12);
            this.label53.TabIndex = 112;
            this.label53.Text = "*";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.Color.Fuchsia;
            this.label52.Location = new System.Drawing.Point(368, 346);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(11, 12);
            this.label52.TabIndex = 111;
            this.label52.Text = "*";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.Color.Fuchsia;
            this.label51.Location = new System.Drawing.Point(368, 313);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(11, 12);
            this.label51.TabIndex = 110;
            this.label51.Text = "*";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.ForeColor = System.Drawing.Color.Fuchsia;
            this.label50.Location = new System.Drawing.Point(368, 279);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(11, 12);
            this.label50.TabIndex = 109;
            this.label50.Text = "*";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.ForeColor = System.Drawing.Color.Fuchsia;
            this.label49.Location = new System.Drawing.Point(368, 249);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(11, 12);
            this.label49.TabIndex = 108;
            this.label49.Text = "*";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.ForeColor = System.Drawing.Color.Fuchsia;
            this.label48.Location = new System.Drawing.Point(368, 214);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(11, 12);
            this.label48.TabIndex = 107;
            this.label48.Text = "*";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.ForeColor = System.Drawing.Color.Fuchsia;
            this.label47.Location = new System.Drawing.Point(368, 184);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(11, 12);
            this.label47.TabIndex = 106;
            this.label47.Text = "*";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.ForeColor = System.Drawing.Color.Fuchsia;
            this.label46.Location = new System.Drawing.Point(368, 115);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(11, 12);
            this.label46.TabIndex = 105;
            this.label46.Text = "*";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.ForeColor = System.Drawing.Color.Fuchsia;
            this.label45.Location = new System.Drawing.Point(368, 80);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(11, 12);
            this.label45.TabIndex = 104;
            this.label45.Text = "*";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.Color.Fuchsia;
            this.label37.Location = new System.Drawing.Point(368, 50);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(11, 12);
            this.label37.TabIndex = 103;
            this.label37.Text = "*";
            // 
            // LoadTips2
            // 
            this.LoadTips2.AutoSize = true;
            this.LoadTips2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips2.ForeColor = System.Drawing.Color.Red;
            this.LoadTips2.Location = new System.Drawing.Point(6, 10);
            this.LoadTips2.Name = "LoadTips2";
            this.LoadTips2.Size = new System.Drawing.Size(64, 16);
            this.LoadTips2.TabIndex = 102;
            this.LoadTips2.Text = "label45";
            this.LoadTips2.Visible = false;
            // 
            // button8
            // 
            this.button8.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button8.Location = new System.Drawing.Point(583, 10);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(66, 23);
            this.button8.TabIndex = 101;
            this.button8.Text = "录 入";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button9_Click);
            // 
            // Glade
            // 
            this.Glade.Location = new System.Drawing.Point(150, 275);
            this.Glade.Name = "Glade";
            this.Glade.Size = new System.Drawing.Size(212, 21);
            this.Glade.TabIndex = 100;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label44.Location = new System.Drawing.Point(88, 278);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 12);
            this.label44.TabIndex = 99;
            this.label44.Text = "年    级：";
            // 
            // StudentId1
            // 
            this.StudentId1.Location = new System.Drawing.Point(265, 12);
            this.StudentId1.Name = "StudentId1";
            this.StudentId1.Size = new System.Drawing.Size(150, 21);
            this.StudentId1.TabIndex = 96;
            // 
            // MobilePhoneNum
            // 
            this.MobilePhoneNum.Location = new System.Drawing.Point(518, 449);
            this.MobilePhoneNum.Name = "MobilePhoneNum";
            this.MobilePhoneNum.Size = new System.Drawing.Size(239, 21);
            this.MobilePhoneNum.TabIndex = 95;
            // 
            // DormPhoneNum
            // 
            this.DormPhoneNum.Location = new System.Drawing.Point(518, 415);
            this.DormPhoneNum.Name = "DormPhoneNum";
            this.DormPhoneNum.Size = new System.Drawing.Size(239, 21);
            this.DormPhoneNum.TabIndex = 94;
            // 
            // HomePhoneNum
            // 
            this.HomePhoneNum.Location = new System.Drawing.Point(518, 380);
            this.HomePhoneNum.Name = "HomePhoneNum";
            this.HomePhoneNum.Size = new System.Drawing.Size(239, 21);
            this.HomePhoneNum.TabIndex = 93;
            // 
            // DormAddr
            // 
            this.DormAddr.Location = new System.Drawing.Point(518, 342);
            this.DormAddr.Name = "DormAddr";
            this.DormAddr.Size = new System.Drawing.Size(239, 21);
            this.DormAddr.TabIndex = 92;
            // 
            // PostalCode
            // 
            this.PostalCode.Location = new System.Drawing.Point(518, 309);
            this.PostalCode.Name = "PostalCode";
            this.PostalCode.Size = new System.Drawing.Size(239, 21);
            this.PostalCode.TabIndex = 91;
            // 
            // NowFamAddr
            // 
            this.NowFamAddr.Location = new System.Drawing.Point(518, 275);
            this.NowFamAddr.Name = "NowFamAddr";
            this.NowFamAddr.Size = new System.Drawing.Size(239, 21);
            this.NowFamAddr.TabIndex = 90;
            // 
            // FamilyAddr
            // 
            this.FamilyAddr.Location = new System.Drawing.Point(518, 241);
            this.FamilyAddr.Name = "FamilyAddr";
            this.FamilyAddr.Size = new System.Drawing.Size(239, 21);
            this.FamilyAddr.TabIndex = 89;
            // 
            // ShengYuanD
            // 
            this.ShengYuanD.Location = new System.Drawing.Point(520, 209);
            this.ShengYuanD.Name = "ShengYuanD";
            this.ShengYuanD.Size = new System.Drawing.Size(237, 21);
            this.ShengYuanD.TabIndex = 88;
            // 
            // ExamineID
            // 
            this.ExamineID.Location = new System.Drawing.Point(520, 174);
            this.ExamineID.Name = "ExamineID";
            this.ExamineID.Size = new System.Drawing.Size(237, 21);
            this.ExamineID.TabIndex = 87;
            // 
            // IDNumber
            // 
            this.IDNumber.Location = new System.Drawing.Point(520, 139);
            this.IDNumber.Name = "IDNumber";
            this.IDNumber.Size = new System.Drawing.Size(237, 21);
            this.IDNumber.TabIndex = 86;
            // 
            // Birthdate
            // 
            this.Birthdate.Location = new System.Drawing.Point(520, 106);
            this.Birthdate.Name = "Birthdate";
            this.Birthdate.Size = new System.Drawing.Size(237, 21);
            this.Birthdate.TabIndex = 85;
            // 
            // StudentId2
            // 
            this.StudentId2.Location = new System.Drawing.Point(150, 46);
            this.StudentId2.Name = "StudentId2";
            this.StudentId2.Size = new System.Drawing.Size(212, 21);
            this.StudentId2.TabIndex = 84;
            // 
            // JiGuan
            // 
            this.JiGuan.Location = new System.Drawing.Point(520, 46);
            this.JiGuan.Name = "JiGuan";
            this.JiGuan.Size = new System.Drawing.Size(237, 21);
            this.JiGuan.TabIndex = 83;
            // 
            // MingZhu
            // 
            this.MingZhu.Location = new System.Drawing.Point(150, 449);
            this.MingZhu.Name = "MingZhu";
            this.MingZhu.Size = new System.Drawing.Size(212, 21);
            this.MingZhu.TabIndex = 82;
            // 
            // XueZhi
            // 
            this.XueZhi.Location = new System.Drawing.Point(150, 415);
            this.XueZhi.Name = "XueZhi";
            this.XueZhi.Size = new System.Drawing.Size(212, 21);
            this.XueZhi.TabIndex = 81;
            // 
            // EntryTime
            // 
            this.EntryTime.Location = new System.Drawing.Point(150, 380);
            this.EntryTime.Name = "EntryTime";
            this.EntryTime.Size = new System.Drawing.Size(212, 21);
            this.EntryTime.TabIndex = 80;
            // 
            // StudentCatogary
            // 
            this.StudentCatogary.Location = new System.Drawing.Point(150, 342);
            this.StudentCatogary.Name = "StudentCatogary";
            this.StudentCatogary.Size = new System.Drawing.Size(212, 21);
            this.StudentCatogary.TabIndex = 79;
            // 
            // Class
            // 
            this.Class.Location = new System.Drawing.Point(150, 309);
            this.Class.Name = "Class";
            this.Class.Size = new System.Drawing.Size(212, 21);
            this.Class.TabIndex = 78;
            // 
            // Professal
            // 
            this.Professal.Location = new System.Drawing.Point(150, 245);
            this.Professal.Name = "Professal";
            this.Professal.Size = new System.Drawing.Size(212, 21);
            this.Professal.TabIndex = 77;
            // 
            // Academy
            // 
            this.Academy.Location = new System.Drawing.Point(150, 211);
            this.Academy.Name = "Academy";
            this.Academy.Size = new System.Drawing.Size(212, 21);
            this.Academy.TabIndex = 76;
            // 
            // School
            // 
            this.School.Location = new System.Drawing.Point(150, 179);
            this.School.Name = "School";
            this.School.Size = new System.Drawing.Size(212, 21);
            this.School.TabIndex = 75;
            // 
            // UsedName
            // 
            this.UsedName.Location = new System.Drawing.Point(150, 144);
            this.UsedName.Name = "UsedName";
            this.UsedName.Size = new System.Drawing.Size(212, 21);
            this.UsedName.TabIndex = 74;
            // 
            // Sex
            // 
            this.Sex.Location = new System.Drawing.Point(150, 110);
            this.Sex.Name = "Sex";
            this.Sex.Size = new System.Drawing.Size(212, 21);
            this.Sex.TabIndex = 73;
            // 
            // StudentName
            // 
            this.StudentName.Location = new System.Drawing.Point(150, 76);
            this.StudentName.Name = "StudentName";
            this.StudentName.Size = new System.Drawing.Size(212, 21);
            this.StudentName.TabIndex = 72;
            // 
            // ZhengZhiMM
            // 
            this.ZhengZhiMM.Location = new System.Drawing.Point(520, 75);
            this.ZhengZhiMM.Name = "ZhengZhiMM";
            this.ZhengZhiMM.Size = new System.Drawing.Size(237, 21);
            this.ZhengZhiMM.TabIndex = 71;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.Color.BlueViolet;
            this.label34.Location = new System.Drawing.Point(160, 15);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(101, 12);
            this.label34.TabIndex = 70;
            this.label34.Text = "请输入学生学号：";
            // 
            // button7
            // 
            this.button7.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.Location = new System.Drawing.Point(508, 10);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(66, 23);
            this.button7.TabIndex = 69;
            this.button7.Text = "修 改";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button6.Location = new System.Drawing.Point(432, 10);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(68, 23);
            this.button6.TabIndex = 68;
            this.button6.TabStop = false;
            this.button6.Text = "查 询";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button7_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label25.Location = new System.Drawing.Point(450, 452);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 67;
            this.label25.Text = "手机号码：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label24.Location = new System.Drawing.Point(449, 418);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 66;
            this.label24.Text = "宿舍电话：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label23.Location = new System.Drawing.Point(449, 383);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 65;
            this.label23.Text = "家庭电话：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label22.Location = new System.Drawing.Point(449, 345);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 64;
            this.label22.Text = "宿舍地址：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label26.Location = new System.Drawing.Point(449, 312);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 12);
            this.label26.TabIndex = 63;
            this.label26.Text = "邮政编码：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label27.Location = new System.Drawing.Point(447, 278);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(77, 12);
            this.label27.TabIndex = 62;
            this.label27.Text = "现家庭住址：";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label28.Location = new System.Drawing.Point(449, 244);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 12);
            this.label28.TabIndex = 61;
            this.label28.Text = "家庭住址：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label29.Location = new System.Drawing.Point(451, 212);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 60;
            this.label29.Text = "生 源 地：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label30.Location = new System.Drawing.Point(451, 177);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 59;
            this.label30.Text = "考 生 号：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label31.Location = new System.Drawing.Point(451, 144);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 58;
            this.label31.Text = "身份证号：";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label32.Location = new System.Drawing.Point(451, 109);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 57;
            this.label32.Text = "出生年月：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label33.Location = new System.Drawing.Point(451, 79);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 12);
            this.label33.TabIndex = 56;
            this.label33.Text = "政治面貌：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label13.Location = new System.Drawing.Point(451, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 12);
            this.label13.TabIndex = 55;
            this.label13.Text = "籍    贯：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(88, 248);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 54;
            this.label9.Text = "专    业：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label10.Location = new System.Drawing.Point(88, 312);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 53;
            this.label10.Text = "班    别：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(88, 345);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 52;
            this.label11.Text = "学生类别：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(88, 383);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 51;
            this.label12.Text = "入学时间：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label14.Location = new System.Drawing.Point(88, 418);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 50;
            this.label14.Text = "学    制：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label15.Location = new System.Drawing.Point(88, 452);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 49;
            this.label15.Text = "民    族：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label16.Location = new System.Drawing.Point(88, 214);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 48;
            this.label16.Text = "学 院/系：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label17.Location = new System.Drawing.Point(88, 182);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 47;
            this.label17.Text = "学    校：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label18.Location = new System.Drawing.Point(88, 147);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 12);
            this.label18.TabIndex = 46;
            this.label18.Text = "曾 用 名：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label19.Location = new System.Drawing.Point(88, 113);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 12);
            this.label19.TabIndex = 45;
            this.label19.Text = "性    别：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label20.Location = new System.Drawing.Point(88, 79);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 12);
            this.label20.TabIndex = 44;
            this.label20.Text = "姓    名：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label21.Location = new System.Drawing.Point(88, 49);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 43;
            this.label21.Text = "学    号：";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.label36);
            this.tabPage1.Controls.Add(this.LoadTips1);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.UserName);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.label43);
            this.tabPage1.Controls.Add(this.Pwd);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(860, 481);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "用户管理";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button5.Location = new System.Drawing.Point(4, 454);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(246, 27);
            this.button5.TabIndex = 32;
            this.button5.Text = "显示所有用户";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "学生",
            "管理员"});
            this.comboBox3.Location = new System.Drawing.Point(502, 99);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(185, 20);
            this.comboBox3.TabIndex = 31;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.ForeColor = System.Drawing.Color.BlueViolet;
            this.label36.Location = new System.Drawing.Point(431, 105);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(59, 12);
            this.label36.TabIndex = 30;
            this.label36.Text = "身   份：";
            // 
            // LoadTips1
            // 
            this.LoadTips1.AutoSize = true;
            this.LoadTips1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips1.ForeColor = System.Drawing.Color.Red;
            this.LoadTips1.Location = new System.Drawing.Point(429, 37);
            this.LoadTips1.Name = "LoadTips1";
            this.LoadTips1.Size = new System.Drawing.Size(87, 21);
            this.LoadTips1.TabIndex = 29;
            this.LoadTips1.Text = "label45";
            this.LoadTips1.Visible = false;
            // 
            // button4
            // 
            this.button4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button4.Location = new System.Drawing.Point(507, 355);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(103, 31);
            this.button4.TabIndex = 26;
            this.button4.Text = "删 除";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button23_Click);
            // 
            // UserName
            // 
            this.UserName.ForeColor = System.Drawing.Color.Black;
            this.UserName.Location = new System.Drawing.Point(502, 159);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(185, 21);
            this.UserName.TabIndex = 24;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.ForeColor = System.Drawing.Color.BlueViolet;
            this.label40.Location = new System.Drawing.Point(431, 164);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(65, 12);
            this.label40.TabIndex = 23;
            this.label40.Text = "用 户 名：";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.Color.BlueViolet;
            this.label43.Location = new System.Drawing.Point(431, 223);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(65, 12);
            this.label43.TabIndex = 21;
            this.label43.Text = "密    码：";
            // 
            // Pwd
            // 
            this.Pwd.ForeColor = System.Drawing.Color.Black;
            this.Pwd.Location = new System.Drawing.Point(502, 219);
            this.Pwd.Name = "Pwd";
            this.Pwd.Size = new System.Drawing.Size(185, 21);
            this.Pwd.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(433, 307);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 31);
            this.button1.TabIndex = 27;
            this.button1.Text = "查 询";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button24_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button2.Location = new System.Drawing.Point(584, 307);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 31);
            this.button2.TabIndex = 28;
            this.button2.Text = "添 加";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button25_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(255, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 477);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(247, 450);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.班级统计);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(-2, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(868, 507);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.linkLabel2);
            this.tabPage5.Controls.Add(this.ImportXL);
            this.tabPage5.Controls.Add(this.textBox3);
            this.tabPage5.Controls.Add(this.OpenFileDialog);
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(860, 481);
            this.tabPage5.TabIndex = 11;
            this.tabPage5.Text = "校历";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.linkLabel2.Location = new System.Drawing.Point(6, 11);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(126, 14);
            this.linkLabel2.TabIndex = 35;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Excel文件格式说明";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // ImportXL
            // 
            this.ImportXL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.ImportXL.Location = new System.Drawing.Point(743, 6);
            this.ImportXL.Name = "ImportXL";
            this.ImportXL.Size = new System.Drawing.Size(103, 27);
            this.ImportXL.TabIndex = 32;
            this.ImportXL.Text = "校历导入";
            this.ImportXL.UseVisualStyleBackColor = true;
            this.ImportXL.Click += new System.EventHandler(this.ImportXL_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(136, 9);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(473, 21);
            this.textBox3.TabIndex = 31;
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.OpenFileDialog.Location = new System.Drawing.Point(621, 6);
            this.OpenFileDialog.Name = "OpenFileDialog";
            this.OpenFileDialog.Size = new System.Drawing.Size(102, 27);
            this.OpenFileDialog.TabIndex = 30;
            this.OpenFileDialog.Text = "浏览Excel文件";
            this.OpenFileDialog.UseVisualStyleBackColor = true;
            this.OpenFileDialog.Click += new System.EventHandler(this.OpenFileDialog_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.listBox3);
            this.groupBox7.ForeColor = System.Drawing.Color.Gray;
            this.groupBox7.Location = new System.Drawing.Point(613, 236);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(241, 239);
            this.groupBox7.TabIndex = 29;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "错误列表";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.HorizontalScrollbar = true;
            this.listBox3.ItemHeight = 12;
            this.listBox3.Location = new System.Drawing.Point(6, 13);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(229, 220);
            this.listBox3.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.LoadTips7);
            this.groupBox10.Controls.Add(this.comboBox4);
            this.groupBox10.Controls.Add(this.label67);
            this.groupBox10.Controls.Add(this.AlterXL);
            this.groupBox10.Controls.Add(this.SelectXL);
            this.groupBox10.ForeColor = System.Drawing.Color.Gray;
            this.groupBox10.Location = new System.Drawing.Point(613, 42);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(241, 187);
            this.groupBox10.TabIndex = 28;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "校历查询修改";
            // 
            // LoadTips7
            // 
            this.LoadTips7.AutoSize = true;
            this.LoadTips7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips7.ForeColor = System.Drawing.Color.Red;
            this.LoadTips7.Location = new System.Drawing.Point(12, 17);
            this.LoadTips7.Name = "LoadTips7";
            this.LoadTips7.Size = new System.Drawing.Size(64, 16);
            this.LoadTips7.TabIndex = 9;
            this.LoadTips7.Text = "label68";
            this.LoadTips7.Visible = false;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "2009-2010学年第一学期",
            "2009-2010学年第二学期",
            "2010-2011学年第一学期",
            "2010-2011学年第二学期",
            "2011-2012学年第一学期",
            "2011-2012学年第二学期",
            "2012-2013学年第一学期",
            "2012-2013学年第二学期"});
            this.comboBox4.Location = new System.Drawing.Point(57, 61);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(174, 20);
            this.comboBox4.TabIndex = 8;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.ForeColor = System.Drawing.Color.BlueViolet;
            this.label67.Location = new System.Drawing.Point(13, 64);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(41, 12);
            this.label67.TabIndex = 1;
            this.label67.Text = "学期：";
            // 
            // AlterXL
            // 
            this.AlterXL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.AlterXL.Location = new System.Drawing.Point(130, 127);
            this.AlterXL.Name = "AlterXL";
            this.AlterXL.Size = new System.Drawing.Size(101, 33);
            this.AlterXL.TabIndex = 7;
            this.AlterXL.Text = "修 改";
            this.AlterXL.UseVisualStyleBackColor = true;
            this.AlterXL.Click += new System.EventHandler(this.AlterXL_Click);
            // 
            // SelectXL
            // 
            this.SelectXL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SelectXL.Location = new System.Drawing.Point(21, 127);
            this.SelectXL.Name = "SelectXL";
            this.SelectXL.Size = new System.Drawing.Size(101, 33);
            this.SelectXL.TabIndex = 4;
            this.SelectXL.Text = "查 询";
            this.SelectXL.UseVisualStyleBackColor = true;
            this.SelectXL.Click += new System.EventHandler(this.SelectXL_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView5.Location = new System.Drawing.Point(6, 36);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowTemplate.Height = 23;
            this.dataGridView5.Size = new System.Drawing.Size(601, 439);
            this.dataGridView5.TabIndex = 0;
            this.dataGridView5.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellValueChanged);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox4);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(860, 481);
            this.tabPage7.TabIndex = 12;
            this.tabPage7.Text = "密码修改";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox4.BackgroundImage")));
            this.groupBox4.Controls.Add(this.LoadTips8);
            this.groupBox4.Controls.Add(this.SureNewPwd);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.NewPwd);
            this.groupBox4.Controls.Add(this.UsedPwd);
            this.groupBox4.Controls.Add(this.button11);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.ForeColor = System.Drawing.Color.Gray;
            this.groupBox4.Location = new System.Drawing.Point(-4, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(868, 485);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "密码修改";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.ForeColor = System.Drawing.Color.BlueViolet;
            this.label42.Location = new System.Drawing.Point(310, 120);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(65, 12);
            this.label42.TabIndex = 2;
            this.label42.Text = "原 密 码：";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.BlueViolet;
            this.label41.Location = new System.Drawing.Point(310, 184);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 12);
            this.label41.TabIndex = 3;
            this.label41.Text = "新 密 码：";
            // 
            // button10
            // 
            this.button10.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button10.Location = new System.Drawing.Point(312, 312);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(83, 36);
            this.button10.TabIndex = 0;
            this.button10.Text = "确认修改";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button21_Click);
            // 
            // button11
            // 
            this.button11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button11.Location = new System.Drawing.Point(485, 312);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(88, 36);
            this.button11.TabIndex = 1;
            this.button11.Text = "密码重置";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button20_Click);
            // 
            // UsedPwd
            // 
            this.UsedPwd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UsedPwd.Location = new System.Drawing.Point(381, 117);
            this.UsedPwd.Name = "UsedPwd";
            this.UsedPwd.PasswordChar = '*';
            this.UsedPwd.Size = new System.Drawing.Size(192, 21);
            this.UsedPwd.TabIndex = 4;
            // 
            // NewPwd
            // 
            this.NewPwd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.NewPwd.Location = new System.Drawing.Point(381, 181);
            this.NewPwd.Name = "NewPwd";
            this.NewPwd.PasswordChar = '*';
            this.NewPwd.Size = new System.Drawing.Size(192, 21);
            this.NewPwd.TabIndex = 5;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.Color.BlueViolet;
            this.label39.Location = new System.Drawing.Point(310, 249);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 6;
            this.label39.Text = "密码确认：";
            // 
            // SureNewPwd
            // 
            this.SureNewPwd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SureNewPwd.Location = new System.Drawing.Point(381, 246);
            this.SureNewPwd.Name = "SureNewPwd";
            this.SureNewPwd.PasswordChar = '*';
            this.SureNewPwd.Size = new System.Drawing.Size(192, 21);
            this.SureNewPwd.TabIndex = 7;
            // 
            // LoadTips8
            // 
            this.LoadTips8.AutoSize = true;
            this.LoadTips8.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips8.ForeColor = System.Drawing.Color.Red;
            this.LoadTips8.Location = new System.Drawing.Point(308, 66);
            this.LoadTips8.Name = "LoadTips8";
            this.LoadTips8.Size = new System.Drawing.Size(87, 21);
            this.LoadTips8.TabIndex = 8;
            this.LoadTips8.Text = "label45";
            this.LoadTips8.Visible = false;
            // 
            // AdministratorModule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(864, 506);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "AdministratorModule";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "管理员信息";
            this.Load += new System.EventHandler(this.AdministratorModule_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Exit);
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.班级统计.ResumeLayout(false);
            this.班级统计.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage 班级统计;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox StudentId1;
        private System.Windows.Forms.TextBox MobilePhoneNum;
        private System.Windows.Forms.TextBox DormPhoneNum;
        private System.Windows.Forms.TextBox HomePhoneNum;
        private System.Windows.Forms.TextBox DormAddr;
        private System.Windows.Forms.TextBox PostalCode;
        private System.Windows.Forms.TextBox NowFamAddr;
        private System.Windows.Forms.TextBox FamilyAddr;
        private System.Windows.Forms.TextBox ShengYuanD;
        private System.Windows.Forms.TextBox ExamineID;
        private System.Windows.Forms.TextBox IDNumber;
        private System.Windows.Forms.TextBox Birthdate;
        private System.Windows.Forms.TextBox StudentId2;
        private System.Windows.Forms.TextBox JiGuan;
        private System.Windows.Forms.TextBox MingZhu;
        private System.Windows.Forms.TextBox XueZhi;
        private System.Windows.Forms.TextBox EntryTime;
        private System.Windows.Forms.TextBox StudentCatogary;
        private System.Windows.Forms.TextBox Class;
        private System.Windows.Forms.TextBox Professal;
        private System.Windows.Forms.TextBox Academy;
        private System.Windows.Forms.TextBox School;
        private System.Windows.Forms.TextBox UsedName;
        private System.Windows.Forms.TextBox Sex;
        private System.Windows.Forms.TextBox StudentName;
        private System.Windows.Forms.TextBox ZhengZhiMM;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button btnAlterFRP;
        private System.Windows.Forms.Button btnSelectFRP;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtSnoSC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtClassSC;
        private System.Windows.Forms.TextBox txtGradeSC;
        private System.Windows.Forms.TextBox txtObjSC;
        private System.Windows.Forms.Button btnCount1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button openFile;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.TextBox txtCno;
        private System.Windows.Forms.TextBox txtSno;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button addORalter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button importScore;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button btnClear1;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnClear2;
        private System.Windows.Forms.Button btnCount2;
        private System.Windows.Forms.TextBox Glade;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label LoadTips2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label LoadTips1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox Pwd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button FeeRewPun;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button OpenFileDia;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtSnoFRP;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button AlterXL;
        private System.Windows.Forms.Button SelectXL;
        private System.Windows.Forms.Button ImportXL;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button OpenFileDialog;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label LoadTips7;
        private System.Windows.Forms.Label LoadTips6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox txtCno2;
        private System.Windows.Forms.Button AlterCourse;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button AddCourse;
        private System.Windows.Forms.TextBox txtCno1;
        private System.Windows.Forms.TextBox txtCname;
        private System.Windows.Forms.TextBox txtCtecher;
        private System.Windows.Forms.TextBox txtCredit;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button ExportCourse;
        private System.Windows.Forms.TextBox txtCno3;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label LoadTips5;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Button SelectCourse;
        private System.Windows.Forms.Button ImportCourse;
        private System.Windows.Forms.Button OpenFileDia2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Button AddCourseDis;
        private System.Windows.Forms.TextBox txtCgrade;
        private System.Windows.Forms.TextBox txtCmajor;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label LoadTips4;
        private System.Windows.Forms.Label LoadTips3;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label LoadTips8;
        private System.Windows.Forms.TextBox SureNewPwd;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox NewPwd;
        private System.Windows.Forms.TextBox UsedPwd;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;



    }
}