﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;

namespace WindowsFormsApplication1
{
    public partial class AdministratorModule : Form
    {
        private DataSet table1;
        private DataSet table2;
        private DataSet table3;
        private DataSet table4;
        private System.Data.DataTable dt1;
        private System.Data.DataTable dt2;
        private SqlDataAdapter sda1;
        private SqlDataAdapter sda2;
        private Boolean isUpdate1 = false;
        private Boolean isUpdate2 = false;

        public AdministratorModule()
        {
            InitializeComponent();
        }
        
        //管理员登录密码修改
        private void button21_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (UsedPwd.Text == "")
                {
                    LoadTips8.Text = "请输入原密码!";
                    LoadTips8.Visible = true;
                }
                else if (NewPwd.Text == "")
                {
                    LoadTips8.Text = "请输入新密码!";
                    LoadTips8.Visible = true;
                }
                else if (SureNewPwd.Text == "")
                {
                    LoadTips8.Text = "请再次输入密码!";
                    LoadTips8.Visible = true;
                }
                else if (NewPwd.Text != SureNewPwd.Text)
                {
                    LoadTips8.Text = "新密码与密码确认不一致!";
                    LoadTips8.Visible = true;
                    NewPwd.Text = "";
                    SureNewPwd.Text = "";
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@UserStatus and YHM=@GuanID and PWD=@UsedPwd", DBConnection.conn);
                    cmd.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = Convert.ToString(GuanliYuan.AdStatus);
                    cmd.Parameters.Add("@GuanID", SqlDbType.NVarChar).Value = Convert.ToString(GuanliYuan.GuanID);
                    cmd.Parameters.Add("@UsedPwd", SqlDbType.NVarChar).Value = UsedPwd.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        r.Close();
                        SqlCommand cmd1 = new SqlCommand("update XX_YHXXB set PWD=@NewPwd where SF=@UserStatus and YHM=@GuanID", DBConnection.conn);
                        cmd1.Parameters.Add("@NewPwd", SqlDbType.NVarChar).Value = NewPwd.Text;
                        cmd1.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = Convert.ToString(GuanliYuan.AdStatus);
                        cmd1.Parameters.Add("@GuanID", SqlDbType.NVarChar).Value = Convert.ToString(GuanliYuan.GuanID);
                        cmd1.ExecuteNonQuery();
                        LoadTips8.Text = "密码修改成功！";
                        LoadTips8.Visible = true;
                        button20_Click(sender,e);
                    }
                    else
                    {
                        LoadTips8.Text = "原密码不正确，请重新输入!";
                        LoadTips8.Visible = true;
                        UsedPwd.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally{ DBConnection.conn.Close();}
        }
        
        //密码重置
        private void button20_Click(object sender, EventArgs e)
        {
            UsedPwd.Text = "";
            NewPwd.Text = "";
            SureNewPwd.Text = "";
        }

        /*管理员窗体加载时显示所有用户*/
        private void AdministratorModule_Load(object sender, EventArgs e)
        {
            try
            {
                string selectSql;
                selectSql = string.Format("select YHM as '用户名',SF as '身份' from XX_YHXXB");
                dgvShow(selectSql, dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*显示所有用户*/
        private void button2_Click(object sender, EventArgs e)
        {
            AdministratorModule_Load(sender,e);
        }

        //用户登录密码查询
        private void button24_Click(object sender, EventArgs e)
        {
            LoadTips1.Visible = false;
            try
            {
                if(comboBox3.Text=="")
                {
                    LoadTips1.Text = "请选择用户身份!";
                    LoadTips1.Visible = true;
                }
                else if (UserName.Text == "")
                {
                    LoadTips1.Text = "请输入用户名!";
                    LoadTips1.Visible = true;
                }
                else
                {
                    DBConnection.conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where YHM=@UserName and SF=@UserStatus", DBConnection.conn);
                    cmd.Parameters.Add("@UserStatus",SqlDbType.NVarChar).Value=comboBox3.Text;
                    cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        Pwd.Text = Convert.ToString(r["PWD"]);
                        r.Close();
                    }
                    else
                    {
                        LoadTips1.Text = "不存在此用户!";
                        LoadTips1.Visible = true;
                        Pwd.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
       
        //添加用户
        private void button25_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if(comboBox3.Text=="")
                {
                    LoadTips1.Text = "请选择用户身份!";
                    LoadTips1.Visible = true;
                }
                else if (UserName.Text == "")
                {
                    LoadTips1.Text = "请输入用户名!";
                    LoadTips1.Visible = true;
                }
                else if (Pwd.Text == "")
                {
                    LoadTips1.Text = "请输入密码!";
                    LoadTips1.Visible = true;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@UserStatus and YHM=@UserName", DBConnection.conn);
                    cmd.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = comboBox3.Text;
                    cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        r.Close();
                        LoadTips1.Text = "此用户已存在!";
                        LoadTips1.Visible = true;
                    }
                    else
                    {
                        r.Close();
                        SqlCommand cmd1 = new SqlCommand("insert into XX_YHXXB(YHM,PWD,SF) values(@UserName,@Pwd,@SF)", DBConnection.conn);
                        cmd1.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                        cmd1.Parameters.Add("@Pwd", SqlDbType.NVarChar).Value = Pwd.Text;
                        cmd1.Parameters.Add("@SF", SqlDbType.NVarChar).Value = comboBox3.Text;
                        cmd1.ExecuteNonQuery();
                        LoadTips1.Text = "添加用户成功！";
                        LoadTips1.Visible = true;
                        string selectSql;
                        selectSql = string.Format("select YHM as '用户名',SF as '身份' from XX_YHXXB where YHM='{0}'",UserName.Text);
                        dgvShow(selectSql, dataGridView1);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
        
        //修改用户的登录密码
        private void button22_Click(object sender, EventArgs e)
        {
            try
            {
                if(comboBox3.Text=="")
                {
                    LoadTips1.Text = "请选择用户身份!";
                    LoadTips1.Visible = true;
                }
                else if (UserName.Text == "")
                {
                    LoadTips1.Text = "请输入用户名!";
                    LoadTips1.Visible = true;
                }
                else if (Pwd.Text == "")
                {
                    LoadTips1.Text = "请输入新密码!";
                    LoadTips1.Visible = true;
                }
                else
                {
                    DBConnection.conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@UserStatus and YHM=@UserName", DBConnection.conn);
                    cmd.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = comboBox3.Text;
                    cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        string pwd = Convert.ToString(r["PWD"]);
                        if (pwd == Pwd.Text)
                        {
                            LoadTips1.Text = "请输入新密码!";
                            LoadTips1.Visible = true;
                            r.Close();
                        }
                        else
                        {
                            r.Close();
                            if(MessageBox.Show("确定修改此用户密码？","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                SqlCommand cmd1 = new SqlCommand("update XX_YHXXB set PWD=@Pwd where SF=@UserStatus and YHM=@UserName", DBConnection.conn);
                                cmd1.Parameters.Add("@Pwd", SqlDbType.NVarChar).Value = Pwd.Text;
                                cmd1.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = comboBox3.Text;
                                cmd1.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                                cmd1.ExecuteNonQuery();
                                LoadTips1.Text = "密码修改成功！";
                                LoadTips1.Visible = true;
                            }
                        }
                    }
                    else
                    {
                        LoadTips1.Text = "不存在此用户!";
                        LoadTips1.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
        
        //删除用户
        private void button23_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@UserStatus and YHM=@UserName", DBConnection.conn);
                cmd.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = comboBox3.Text;
                cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    r.Close();
                    if(MessageBox.Show("确定删除此用户？","提示",MessageBoxButtons.YesNo,MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        SqlCommand cmd1 = new SqlCommand("delete from XX_YHXXB where SF=@UserStatus and YHM=@UserName", DBConnection.conn);
                        cmd1.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = comboBox3.Text;
                        cmd1.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                        cmd1.ExecuteNonQuery();
                        LoadTips1.Text = "用户删除成功！";
                        LoadTips1.Visible = true;
                        AdministratorModule_Load(sender, e);
                    }
                }
                else
                {
                    LoadTips1.Text = "不存在此用户!";
                    LoadTips1.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
        
        //查询学生档案
        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (StudentId1.Text == "")
                {
                    LoadTips2.Text = "请输入学号!";
                    LoadTips2.Visible = true;
                }
                else
                {
                    DBConnection.conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from XX_DA where XH=@StudentId1", DBConnection.conn);
                    cmd.Parameters.Add("@StudentId1", SqlDbType.NVarChar).Value = StudentId1.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        StudentId2.Text = Convert.ToString(r["XH"]);
                        StudentName.Text = Convert.ToString(r["XM"]);
                        Sex.Text = Convert.ToString(r["XB"]);
                        UsedName.Text = Convert.ToString(r["CYM"]);
                        School.Text = Convert.ToString(r["XX"]);
                        Academy.Text = Convert.ToString(r["XY"]);
                        Professal.Text = Convert.ToString(r["ZY"]);
                        Glade.Text = Convert.ToString(r["NJ"]);
                        Class.Text = Convert.ToString(r["BB"]);
                        StudentCatogary.Text = Convert.ToString(r["XSLB"]);
                        EntryTime.Text = Convert.ToString(r["RXSJ"]);
                        XueZhi.Text = Convert.ToString(r["XZ"]);
                        MingZhu.Text = Convert.ToString(r["MZ"]);
                        JiGuan.Text = Convert.ToString(r["JG"]);
                        ZhengZhiMM.Text = Convert.ToString(r["ZZMM"]);
                        Birthdate.Text = Convert.ToString(r["CSNY"]);
                        IDNumber.Text = Convert.ToString(r["SFZH"]);
                        ExamineID.Text = Convert.ToString(r["KSH"]);
                        ShengYuanD.Text = Convert.ToString(r["SYD"]);
                        FamilyAddr.Text = Convert.ToString(r["JTZZ"]);
                        NowFamAddr.Text = Convert.ToString(r["XJTZZ"]);
                        PostalCode.Text = Convert.ToString(r["YZBM"]);
                        DormAddr.Text = Convert.ToString(r["SSDZ"]);
                        HomePhoneNum.Text = Convert.ToString(r["JTDH"]);
                        DormPhoneNum.Text = Convert.ToString(r["SSDH"]);
                        MobilePhoneNum.Text = Convert.ToString(r["SJH"]);
                        r.Close();
                        LoadTips2.Visible = false;
                    }
                    else
                    {
                        LoadTips2.Text = "不存在该学生档案!";
                        button1_Click(sender,e);
                        LoadTips2.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
        
        //修改学生档案信息
        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                if (StudentId2.Text == "")
                {
                    LoadTips2.Text = "学号不能为空!";
                    LoadTips2.Visible = true;
                }
                else
                {
                    DBConnection.conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from XX_DA where XH=@StudentId2", DBConnection.conn);
                    cmd.Parameters.Add("@StudentId2", SqlDbType.NVarChar).Value = StudentId2.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        if (StudentName.Text == "")
                        {
                            LoadTips2.Text = "姓名不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Sex.Text == "")
                        {
                            LoadTips2.Text = "性别不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (School.Text == "")
                        {
                            LoadTips2.Text = "学校不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Academy.Text == "")
                        {
                            LoadTips2.Text = "学院不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Professal.Text == "")
                        {
                            LoadTips2.Text = "专业不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Glade.Text == "")
                        {
                            LoadTips2.Text = "年级不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Class.Text == "")
                        {
                            LoadTips2.Text = "班别不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (StudentCatogary.Text == "")
                        {
                            LoadTips2.Text = "学生类别不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (EntryTime.Text == "")
                        {
                            LoadTips2.Text = "入学时间不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (XueZhi.Text == "")
                        {
                            LoadTips2.Text = "学制不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (MingZhu.Text == "")
                        {
                            LoadTips2.Text = "民族不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (JiGuan.Text == "")
                        {
                            LoadTips2.Text = "籍贯不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (IDNumber.Text == "")
                        {
                            LoadTips2.Text = "身份证号不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (ExamineID.Text == "")
                        {
                            LoadTips2.Text = "考生号不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (ShengYuanD.Text == "")
                        {
                            LoadTips2.Text = "生源地不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (FamilyAddr.Text == "")
                        {
                            LoadTips2.Text = "家庭住址不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (NowFamAddr.Text == "")
                        {
                            LoadTips2.Text = "现家庭住址不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (PostalCode.Text == "")
                        {
                            LoadTips2.Text = "邮政编码不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (DormAddr.Text == "")
                        {
                            LoadTips2.Text = "宿舍地址不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (HomePhoneNum.Text == "")
                        {
                            LoadTips2.Text = "家庭电话不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (MobilePhoneNum.Text == "")
                        {
                            LoadTips2.Text = "手机号不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else
                        {
                            r.Close();
                            if (MessageBox.Show("确定要修改档案信息吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
                            {
                                string str;
                                str = string.Format("update XX_DA set XM=@StudentName,XB=@Sex,CYM=@UsedName,SFZH=@IDNumber,CSNY=@Birthdate,ZZMM=@ZhengZhiMM,");
                                str += string.Format(" MZ=@MingZhu,JG=@JiGuan,SYD=@ShengYuanD,XX=@School,XY=@Academy,ZY=@Professal,NJ=@Glade,BB=@Class,RXSJ=@EntryTime,");
                                str += string.Format(" XSLB=@StudentCatogary,XZ=@XueZhi,KSH=@ExamineID,XJTZZ=@NowFamAddr,JTZZ=@FamilyAddr,JTDH=@HomePhoneNum,");
                                str += string.Format(" YZBM=@PostalCode,SSDZ=@DormAddr,SSDH=@DormPhoneNum,SJH=@MobilePhoneNum where XH=@StudentId2");
                                SqlCommand cmd1 = new SqlCommand(str, DBConnection.conn);
                                cmd1.Parameters.Add("@StudentId2", SqlDbType.NVarChar).Value = StudentId2.Text;
                                cmd1.Parameters.Add("@StudentName", SqlDbType.NVarChar).Value = StudentName.Text;
                                cmd1.Parameters.Add("@Sex", SqlDbType.NVarChar).Value = Sex.Text;
                                cmd1.Parameters.Add("@UsedName", SqlDbType.NVarChar).Value = UsedName.Text;
                                cmd1.Parameters.Add("@IDNumber", SqlDbType.NVarChar).Value = IDNumber.Text;
                                cmd1.Parameters.Add("@Birthdate", SqlDbType.NVarChar).Value = Birthdate.Text;
                                cmd1.Parameters.Add("@ZhengZhiMM", SqlDbType.NVarChar).Value = ZhengZhiMM.Text;
                                cmd1.Parameters.Add("@MingZhu", SqlDbType.NVarChar).Value = MingZhu.Text;
                                cmd1.Parameters.Add("@JiGuan", SqlDbType.NVarChar).Value = JiGuan.Text;
                                cmd1.Parameters.Add("@ShengYuanD", SqlDbType.NVarChar).Value = ShengYuanD.Text;
                                cmd1.Parameters.Add("@School", SqlDbType.NVarChar).Value = School.Text;
                                cmd1.Parameters.Add("@Academy", SqlDbType.NVarChar).Value = Academy.Text;
                                cmd1.Parameters.Add("@Professal", SqlDbType.NVarChar).Value = Professal.Text;
                                cmd1.Parameters.Add("@Glade", SqlDbType.NVarChar).Value = Glade.Text;
                                cmd1.Parameters.Add("@Class", SqlDbType.NVarChar).Value = Class.Text;
                                cmd1.Parameters.Add("@EntryTime", SqlDbType.NVarChar).Value = EntryTime.Text;
                                cmd1.Parameters.Add("@StudentCatogary", SqlDbType.NVarChar).Value = StudentCatogary.Text;
                                cmd1.Parameters.Add("@XueZhi", SqlDbType.NVarChar).Value = XueZhi.Text;
                                cmd1.Parameters.Add("@ExamineID", SqlDbType.NVarChar).Value = ExamineID.Text;
                                cmd1.Parameters.Add("@NowFamAddr", SqlDbType.NVarChar).Value = NowFamAddr.Text;
                                cmd1.Parameters.Add("@FamilyAddr", SqlDbType.NVarChar).Value = FamilyAddr.Text;
                                cmd1.Parameters.Add("@HomePhoneNum", SqlDbType.NVarChar).Value = HomePhoneNum.Text;
                                cmd1.Parameters.Add("@PostalCode", SqlDbType.NVarChar).Value = PostalCode.Text;
                                cmd1.Parameters.Add("@DormAddr", SqlDbType.NVarChar).Value = DormAddr.Text;
                                cmd1.Parameters.Add("@DormPhoneNum", SqlDbType.NVarChar).Value = DormPhoneNum.Text;
                                cmd1.Parameters.Add("@MobilePhoneNum", SqlDbType.NVarChar).Value = MobilePhoneNum.Text;
                                cmd1.ExecuteNonQuery();
                                LoadTips2.Text = "档案修改成功！";
                                LoadTips2.Visible = true;
                            }
                        }
                    }
                    else 
                    {
                        LoadTips2.Text = "不存在该学生档案！";
                        LoadTips2.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
        
        //录入学生档案
        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                if (StudentId2.Text == "")
                {
                    LoadTips2.Text = "学号不能为空!";
                    LoadTips2.Visible = true;
                }
                else
                {
                    DBConnection.conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from XX_DA where XH=@StudentId2", DBConnection.conn);
                    cmd.Parameters.Add("@StudentId2", SqlDbType.NVarChar).Value = StudentId2.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        LoadTips2.Text = "已存在该学生档案!";
                        LoadTips2.Visible = true;
                    }
                    else
                    {
                        r.Close();
                        if (StudentName.Text == "")
                        {
                            LoadTips2.Text = "姓名不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Sex.Text == "")
                        {
                            LoadTips2.Text = "性别不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (School.Text == "")
                        {
                            LoadTips2.Text = "学校不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Academy.Text == "")
                        {
                            LoadTips2.Text = "学院不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Professal.Text == "")
                        {
                            LoadTips2.Text = "专业不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Glade.Text == "")
                        {
                            LoadTips2.Text = "年级不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (Class.Text == "")
                        {
                            LoadTips2.Text = "班别不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (StudentCatogary.Text == "")
                        {
                            LoadTips2.Text = "学生类别不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (EntryTime.Text == "")
                        {
                            LoadTips2.Text = "入学时间不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (XueZhi.Text == "")
                        {
                            LoadTips2.Text = "学制不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (MingZhu.Text == "")
                        {
                            LoadTips2.Text = "民族不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (JiGuan.Text == "")
                        {
                            LoadTips2.Text = "籍贯不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (IDNumber.Text == "")
                        {
                            LoadTips2.Text = "身份证号不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (ExamineID.Text == "")
                        {
                            LoadTips2.Text = "考生号不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (ShengYuanD.Text == "")
                        {
                            LoadTips2.Text = "生源地不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (FamilyAddr.Text == "")
                        {
                            LoadTips2.Text = "家庭所在地不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (NowFamAddr.Text == "")
                        {
                            LoadTips2.Text = "现家庭住址不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (PostalCode.Text == "")
                        {
                            LoadTips2.Text = "邮政编码不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (DormAddr.Text == "")
                        {
                            LoadTips2.Text = "宿舍地址不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (HomePhoneNum.Text == "")
                        {
                            LoadTips2.Text = "家庭电话不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else if (MobilePhoneNum.Text == "")
                        {
                            LoadTips2.Text = "手机号不能为空!";
                            LoadTips2.Visible = true;
                        }
                        else
                        {
                            LoadTips2.Visible = false;
                            string str1;
                            str1 =string.Format( "insert into XX_DA(XH,XM,CYM,SFZH,XB,CSNY,ZZMM,MZ,JG,SYD,XX,XY,");
                            str1 += string.Format("ZY,NJ,BB,RXSJ,XSLB,XZ,KSH,XJTZZ,JTZZ,JTDH,YZBM,SSDZ,SSDH,SJH)");
                            str1 += string.Format("values(@StudentId2,@StudentName,@UsedName,@IDNumber,@Sex,@Birthdate,");
                            str1 += string.Format("@ZhengZhiMM,@MingZhu,@JiGuan,@ShengYuanD,@School,@Academy,@Professal,@Glade,");
                            str1 += string.Format("@Class,@EntryTime,@StudentCatogary,@XueZhi,@ExamineID,@NowFamAddr,");
                            str1 += string.Format("@FamilyAddr,@HomePhoneNum,@PostalCode,@DormAddr,@DormPhoneNum,@MobilePhoneNum)");
                            SqlCommand cmd1 = new SqlCommand(str1,DBConnection.conn);
                            cmd1.Parameters.Add("@StudentId2", SqlDbType.NVarChar).Value = StudentId2.Text;
                            cmd1.Parameters.Add("@StudentName", SqlDbType.NVarChar).Value = StudentName.Text;
                            cmd1.Parameters.Add("@Sex", SqlDbType.NVarChar).Value = Sex.Text;
                            cmd1.Parameters.Add("@UsedName", SqlDbType.NVarChar).Value = UsedName.Text;
                            cmd1.Parameters.Add("@IDNumber", SqlDbType.NVarChar).Value = IDNumber.Text;
                            cmd1.Parameters.Add("@Birthdate", SqlDbType.NVarChar).Value = Birthdate.Text;
                            cmd1.Parameters.Add("@ZhengZhiMM", SqlDbType.NVarChar).Value = ZhengZhiMM.Text;
                            cmd1.Parameters.Add("@MingZhu", SqlDbType.NVarChar).Value = MingZhu.Text;
                            cmd1.Parameters.Add("@JiGuan", SqlDbType.NVarChar).Value = JiGuan.Text;
                            cmd1.Parameters.Add("@ShengYuanD", SqlDbType.NVarChar).Value = ShengYuanD.Text;
                            cmd1.Parameters.Add("@School", SqlDbType.NVarChar).Value = School.Text;
                            cmd1.Parameters.Add("@Academy", SqlDbType.NVarChar).Value = Academy.Text;
                            cmd1.Parameters.Add("@Professal", SqlDbType.NVarChar).Value = Professal.Text;
                            cmd1.Parameters.Add("@Glade", SqlDbType.NVarChar).Value = Glade.Text;
                            cmd1.Parameters.Add("@Class", SqlDbType.NVarChar).Value = Class.Text;
                            cmd1.Parameters.Add("@EntryTime", SqlDbType.NVarChar).Value = EntryTime.Text;
                            cmd1.Parameters.Add("@StudentCatogary", SqlDbType.NVarChar).Value = StudentCatogary.Text;
                            cmd1.Parameters.Add("@XueZhi", SqlDbType.NVarChar).Value = XueZhi.Text;
                            cmd1.Parameters.Add("@ExamineID", SqlDbType.NVarChar).Value = ExamineID.Text;
                            cmd1.Parameters.Add("@NowFamAddr", SqlDbType.NVarChar).Value = NowFamAddr.Text;
                            cmd1.Parameters.Add("@FamilyAddr", SqlDbType.NVarChar).Value = FamilyAddr.Text;
                            cmd1.Parameters.Add("@HomePhoneNum", SqlDbType.NVarChar).Value = HomePhoneNum.Text;
                            cmd1.Parameters.Add("@PostalCode", SqlDbType.NVarChar).Value = PostalCode.Text;
                            cmd1.Parameters.Add("@DormAddr", SqlDbType.NVarChar).Value = DormAddr.Text;
                            cmd1.Parameters.Add("@DormPhoneNum", SqlDbType.NVarChar).Value = DormPhoneNum.Text;
                            cmd1.Parameters.Add("@MobilePhoneNum", SqlDbType.NVarChar).Value = MobilePhoneNum.Text;
                            cmd1.ExecuteNonQuery();
                            SqlCommand cmd2=new SqlCommand("select * from XX_YHXXB where SF='学生' and YHM=@StuNum",DBConnection.conn);
                            cmd2.Parameters.Add("@StuNum", SqlDbType.NVarChar).Value = StudentId2.Text;
                            SqlDataReader r1 = cmd2.ExecuteReader();
                            if (r1.Read())
                            {
                                r1.Close();
                                MessageBox.Show("档案录入成功，但创建用户失败因已存在该学生用户!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                button1_Click(sender, e);
                            }
                            else
                            {
                                r1.Close();
                                SqlCommand cmd3 = new SqlCommand("insert into XX_YHXXB(YHM,PWD,SF) values(@StuNum,@Pwd,'学生')",DBConnection.conn);
                                cmd3.Parameters.Add("@StuNum", SqlDbType.NVarChar).Value = StudentId2.Text;
                                cmd3.Parameters.Add("@Pwd", SqlDbType.NVarChar).Value = StudentId2.Text;
                                cmd3.ExecuteNonQuery();
                                MessageBox.Show("档案录入成功，并且创建用户成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                button1_Click(sender, e);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*重置学生档案录入的相关信息*/
        private void button1_Click(object sender, EventArgs e)
        {
            LoadTips2.Visible = false;
            StudentId2.Text = "";
            StudentName.Text = "";
            Sex.Text = "";
            UsedName.Text = "";
            School.Text = "";
            Academy.Text = "";
            Professal.Text = "";
            Glade.Text = "";
            Class.Text = "";
            StudentCatogary.Text = "";
            EntryTime.Text = "";
            XueZhi.Text = "";
            MingZhu.Text = "";
            JiGuan.Text = "";
            ZhengZhiMM.Text = "";
            Birthdate.Text = "";
            IDNumber.Text = "";
            ExamineID.Text = "";
            ShengYuanD.Text = "";
            FamilyAddr.Text = "";
            NowFamAddr.Text = "";
            PostalCode.Text = "";
            DormAddr.Text = "";
            HomePhoneNum.Text = "";
            DormPhoneNum.Text = "";
            MobilePhoneNum.Text = "";
        }

        /*打开Excel文件*/
        private void OpenFile(DataGridView dgv,DataSet ds,TextBoxBase tb)
        {
            openFileDialog1.Filter = "Excel文件|*.xls";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                tb.Text = openFileDialog1.FileName;
                try
                {
                    string strConn = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source='{0}';Extended Properties=Excel 8.0;", tb.Text);
                    string sql = "select * from [Sheet1$]";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(sql, strConn);
                    adapter.Fill(ds, "Excel");
                    dgv.DataSource = ds.Tables["Excel"];
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /*导出Excel文件*/
        private void ImportFile(DataGridView dgv)
        {
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            excel.Visible = false;
            excel.Application.Workbooks.Add(true);
            for (int i = 0; i < dgv.Columns.Count; i++)
            {
                excel.Cells[1, i + 1] = dgv.Columns[i].HeaderText;
            }
            for (int i = 0; i < dgv.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dgv.Columns.Count; j++)
                {
                    if (dgv[j, i].ValueType == typeof(string))
                    {
                        excel.Cells[i + 2, j + 1] = "'" + dgv[j, i].Value.ToString();
                    }
                    else
                    {
                        excel.Cells[i + 2, j + 1] = dgv[j, i].Value.ToString();
                    }
                }
            }
            excel.DisplayAlerts = false;
            excel.AlertBeforeOverwriting = false;
            excel.Application.Workbooks.Add(true).Save();
            excel.Save("D:" + "\\KKHMD.xls");
            excel.Quit();
            excel = null;
        }

        /*成绩录入浏览Excel文件并显示出文件的内容*/ 
        private void openFile_Click(object sender, EventArgs e)
        {
            try
            {
                table1 = new DataSet();
                OpenFile(dataGridView3,table1,txtPath);
                if (dataGridView3.Rows.Count > 0)
                {
                    if (dataGridView3.Columns[0].HeaderText.Trim() != "学号" || dataGridView3.Columns[1].HeaderText.Trim() != "课程号" || dataGridView3.Columns[2].HeaderText.Trim() != "成绩")
                    {
                        MessageBox.Show("Excel表格格式不正确，请参照标准表格格式!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        table1.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*批量录入成绩*/ 
        private void importScore_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (table1.Tables[0].Rows.Count > 0)
                {
                    string sql = "";
                    SqlCommand myCmd = null;
                    int i = 0;
                    string str1 = "";
                    string str2 = "";
                    listBox1.Items.Clear();
                    for (; i < table1.Tables[0].Rows.Count; i++)
                    {
                        str1 = table1.Tables[0].Rows[i]["学号"].ToString().Trim();
                        str2 = table1.Tables[0].Rows[i]["课程号"].ToString().Trim();
                        sql = string.Format("insert into XX_CJ(XH,KCH,CJ) values (@Sno,@Cno,@Score)");
                        try
                        {
                            if (judge(str1,str2))
                            {
                                myCmd = new SqlCommand(sql, DBConnection.conn);
                                myCmd.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = str1;
                                myCmd.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = str2;
                                myCmd.Parameters.Add("@Score", SqlDbType.NVarChar).Value = table1.Tables[0].Rows[i]["成绩"].ToString().Trim();
                                myCmd.ExecuteNonQuery();
                            }
                            else
                            {
                                listBox2.Items.Add("第" + (i + 1) + "条记录添加失败，原因：不存在该学生或不存在该课程或该学生没有学该课程");
                                continue;
                            }
                        }
                        catch (Exception ex)
                        {
                            listBox2.Items.Add("第" + (i + 1) + "条记录添加失败，错误：" + ex.Message);
                            continue;
                        }
                    }
                    if (i == table1.Tables[0].Rows.Count)
                    {
                        MessageBox.Show("批量录入学生成绩完成","提示",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        MessageBox.Show("第" + (i + 1) + "行添加失败");
                    }
                }
                else { MessageBox.Show("没有任何数据需要录入!","提示",MessageBoxButtons.OK,MessageBoxIcon.Exclamation); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有录入任何数据!\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*在录入成绩前，判断是否存在该学生和课程，判断该学生是否学习该课程*/
        private bool judge(string str1, string str2)
        {
            bool bl = false;
            string sqlJudge1 = string.Format("select count(*) from XX_DA where XH=@Sno");
            SqlCommand selectJudge1 = new SqlCommand(sqlJudge1, DBConnection.conn);
            selectJudge1.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = str1;
            int k = (int)selectJudge1.ExecuteScalar();
            if (k > 0)
            {
                string sqlJudge2 = string.Format("select count(*) from XX_KC where KCH=@Cno");
                SqlCommand selectJudge2 = new SqlCommand(sqlJudge2, DBConnection.conn);
                selectJudge2.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = str2;
                int m = (int)selectJudge2.ExecuteScalar();
                if (m > 0)
                {
                    string sqlJudge3;
                    sqlJudge3 = string.Format("select count(*) from XX_DA,XX_KC,XX_XSKCB");
                    sqlJudge3 += string.Format(" where XX_XSKCB.KCH=XX_KC.KCH and XX_XSKCB.ZY=XX_DA.ZY and XX_XSKCB.NJ=XX_DA.NJ and XX_DA.XH=@Sno and XX_KC.KCH=@Cno");
                    SqlCommand selectJudge3 = new SqlCommand(sqlJudge3, DBConnection.conn);
                    selectJudge3.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = str1;
                    selectJudge3.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = str2;
                    int n = (int)selectJudge3.ExecuteScalar();
                    if (n > 0) bl = true;
                }
            }
            return bl;
        }

        /*单项添加或修改成绩*/
        private void addORalter_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (txtSno.Text == "" || txtCno.Text == "" || txtScore.Text == "")
                {
                    MessageBox.Show("请填完整所有信息!","提示",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
                }
                else
                {
                    string sql = string.Format("select count(*) from XX_CJ where XH=@Sno and KCH=@Cno");
                    SqlCommand sqlselect = new SqlCommand(sql, DBConnection.conn);
                    sqlselect.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = txtSno.Text;
                    sqlselect.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno.Text;
                    int i = (int)sqlselect.ExecuteScalar();
                    if (i == 0)
                    {
                        try
                        {
                            if (MessageBox.Show("确定要添加该学生的成绩吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                if (judge(txtSno.Text, txtCno.Text))
                                {
                                    string sqlInsert, selectScore;
                                    sqlInsert = "insert into XX_CJ(XH,KCH,CJ) values (@Sno,@Cno,@Score)";
                                    selectScore = string.Format("select XX_CJ.XH as '学号',XM as '姓名',XX_KC.KCH as '课程号',KCM as '课程名', CJ as '成绩'");
                                    selectScore += string.Format("from XX_DA,XX_KC,XX_CJ where XX_CJ.XH='{0}'and XX_DA.XH='{0}'and XX_CJ.KCH='{1}'and XX_KC.KCH=XX_CJ.KCH;", txtSno.Text, txtCno.Text);
                                    SqlCommand sqlcmd = new SqlCommand(sqlInsert, DBConnection.conn);
                                    sqlcmd.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = txtSno.Text;
                                    sqlcmd.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno.Text;
                                    sqlcmd.Parameters.Add("@Score", SqlDbType.NVarChar).Value = txtScore.Text;
                                    int j = sqlcmd.ExecuteNonQuery();
                                    if (j > 0)
                                    {
                                        MessageBox.Show("添加成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                        dgvShow(selectScore, dataGridView3);
                                    }
                                }
                                else
                                { MessageBox.Show("添加失败!\n原因：可能不存在该学生或不存在该课程或该学生没有学该课程", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("添加失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        try
                        {
                            if (MessageBox.Show("确定要进行修改吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
                            {
                                string sqlAlter, selectScore;
                                sqlAlter = string.Format("update XX_CJ set CJ='{0}' where XH='{1}'and KCH='{2}'", txtScore.Text, txtSno.Text, txtCno.Text);
                                selectScore = string.Format("select XX_CJ.XH as '学号',XM as '姓名',XX_KC.KCH as '课程号',KCM as '课程名', CJ as '成绩'");
                                selectScore += string.Format("from XX_DA,XX_KC,XX_CJ where XX_CJ.XH='{0}'and XX_DA.XH='{0}'and XX_CJ.KCH='{1}'and XX_KC.KCH=XX_CJ.KCH;", txtSno.Text, txtCno.Text);
                                SqlCommand sqlcmd = new SqlCommand(sqlAlter, DBConnection.conn);
                                int j = sqlcmd.ExecuteNonQuery();
                                if (j > 0)
                                {
                                    MessageBox.Show("修改成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                    dgvShow(selectScore, dataGridView3);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("修改失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*重置单项添加或修改成绩的数据项*/   
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSno.Clear();
            txtCno.Clear();
            txtScore.Clear();
        }

        /*在DataGridView中显示出相应的数据*/
        private void dgvShow(string str,DataGridView dgv)
        {
            DataSet dataset = new DataSet();
            try
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(str, DBConnection.conn);
                dataAdapter.Fill(dataset, "Score");
                dgv.DataSource = dataset.Tables["Score"];
                BindingManagerBase bmb = this.BindingContext[dataset.Tables["Score"]];
                if (dgv.Rows.Count != 0)
                {
                    for (int i = 0; i < dgv.Rows.Count; i += 2)
                    {
                        dgv.Rows[i].DefaultCellStyle.BackColor = System.Drawing.Color.FloralWhite;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*对成绩录入或修改时输入的学号的相应学生成绩进行自动查询*/
        private void Sno_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (txtSno.Text != "")
                {
                    string selectScore;
                    selectScore = string.Format("select XX_CJ.XH as '学号',XM as '姓名',XX_KC.KCH as '课程号',KCM as '课程名', CJ as '成绩',XQ as '学期'");
                    selectScore += string.Format(" from XX_DA,XX_KC,XX_CJ,XX_XSKCB where XX_CJ.XH='{0}' and XX_DA.XH='{0}' and XX_KC.KCH=XX_CJ.KCH",txtSno.Text);
                    selectScore += string.Format(" and XX_DA.ZY=XX_XSKCB.ZY and XX_DA.NJ=XX_XSKCB.NJ and XX_XSKCB.KCH=XX_KC.KCH;");
                    dgvShow(selectScore,dataGridView3);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*对成绩录入或修改时输入的课程号的相应学生成绩进行自动查询*/
        private void Cno_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (txtCno.Text != "")
                {
                    string selectScore;
                    selectScore = string.Format("select XX_CJ.XH as '学号',XM as '姓名',XX_KC.KCH as '课程号',KCM as '课程名', CJ as '成绩',XQ as '学期'");
                    selectScore += string.Format(" from XX_DA,XX_KC,XX_CJ,XX_XSKCB where XX_CJ.KCH='{0}'and XX_KC.KCH=XX_CJ.KCH and XX_DA.XH=XX_CJ.XH", txtCno.Text);
                    selectScore += string.Format(" and XX_DA.ZY=XX_XSKCB.ZY and XX_DA.NJ=XX_XSKCB.NJ and XX_XSKCB.KCH=XX_KC.KCH;");
                    dgvShow(selectScore,dataGridView3);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*进行班级成绩统计*/
        private void btnCount1_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (comboBox1.Text != "" && txtObjSC.Text != "" && txtGradeSC.Text != "" && txtClassSC.Text != "")
                {
                    string selectScore;
                    selectScore = string.Format("select XX_KC.KCH as '课程号',AVG(CJ) as '平均分',MAX(CJ) as '最高分',MIN(CJ) as '最低分' from XX_CJ,XX_KC ");
                    selectScore += string.Format("where XX_CJ.KCH in (select KCH from XX_XSKCB where XQ='{0}' and ZY='{1}' and NJ='{2}')", comboBox1.Text, txtObjSC.Text, txtGradeSC.Text);
                    selectScore += string.Format(" and XH in(select XH from XX_DA where ZY='{0}' and NJ='{1}' and BB='{2}') and XX_KC.KCH=XX_CJ.KCH group by XX_KC.KCH;", txtObjSC.Text, txtGradeSC.Text, txtClassSC.Text);
                    dgvShow(selectScore, dataGridView4);
                }
                else { MessageBox.Show("请填完整信息项!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*重置班级成绩的统计条件*/
        private void btnClear1_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            txtObjSC.Clear();
            txtGradeSC.Clear();
            txtClassSC.Clear();
        }

        /*导出班级成绩统计的结果*/
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView4.Rows.Count == 1)
                {
                    MessageBox.Show("没有任何要导出的数据！","错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return; 
                }
                ImportFile(dataGridView4);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误提示");
            }
        }

        /*进行个人成绩统计*/
        private void btnCount2_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (comboBox2.Text != "" && txtSnoSC.Text != "")
                {
                    string selectScore;
                    selectScore = string.Format("select distinct XH as '学号',XM as '姓名',(select AVG(CJ) from XX_CJ where XH='{0}'and KCH in", txtSnoSC.Text);
                    selectScore += string.Format("(select KCH from XX_DA,XX_XSKCB where XH='{0}' and XX_XSKCB.ZY=XX_DA.ZY and XX_XSKCB.NJ=XX_DA.NJ and XQ='{1}'))", txtSnoSC.Text, comboBox2.Text);
                    selectScore += string.Format(" as '平均分',XQ as '学期'from XX_DA,XX_KC,XX_XSKCB where XH='{0}' and XQ='{1}'", txtSnoSC.Text, comboBox2.Text);
                    dgvShow(selectScore,dataGridView4);
                }
                else { MessageBox.Show("请填完整信息项!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*重置个人成绩统计的条件*/
        private void btnClear2_Click(object sender, EventArgs e)
        {
            comboBox2.Text = "";
            txtSnoSC.Clear();
        }

        /*学费、奖惩导入浏览Excel文件并显示出文件的内容*/
        private void openFileDia_Click(object sender, EventArgs e)
        {
            try
            {
                table2 = new DataSet();
                OpenFile(dataGridView2, table2,textBox1);
                if (dataGridView2.Rows.Count> 0)
                {
                    if (dataGridView2.Columns[0].HeaderText.Trim() != "学号" || dataGridView2.Columns[1].HeaderText.Trim() != "姓名"
                        || dataGridView2.Columns[2].HeaderText.Trim() != "学期" || dataGridView2.Columns[3].HeaderText.Trim() != "学院"
                        || dataGridView2.Columns[4].HeaderText.Trim() != "专业" || dataGridView2.Columns[5].HeaderText.Trim() != "年级"
                        || dataGridView2.Columns[6].HeaderText.Trim() != "班别" || dataGridView2.Columns[7].HeaderText.Trim() != "已缴费"
                        || dataGridView2.Columns[8].HeaderText.Trim() != "欠费" || dataGridView2.Columns[9].HeaderText.Trim() != "奖励"
                        || dataGridView2.Columns[10].HeaderText.Trim() != "处分")
                    {
                        MessageBox.Show("Excel表格格式不正确，请参照标准表格格式!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        table2.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*批量导入学费、奖惩信息*/
        private void FeeRewPun_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (table2.Tables[0].Rows.Count > 0)
                {
                    string sql = "";
                    int i = 0;
                    SqlCommand myCmd = null;
                    listBox1.Items.Clear();
                    for (; i < table2.Tables[0].Rows.Count; i++)
                    {
                        sql = string.Format("insert into XX_XFJC(XH,XQ,YJF,QF,JL,CF) values (@Sno,@XQ,@YJF,@QF,@JL,@CF)");
                        try
                        {
                            string sqlJudge1 = string.Format("select count(*) from XX_DA where XH=@Sno");
                            SqlCommand selectJudge1 = new SqlCommand(sqlJudge1, DBConnection.conn);
                            selectJudge1.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = table2.Tables[0].Rows[i]["学号"].ToString().Trim();
                            int k = (int)selectJudge1.ExecuteScalar();
                            if (k > 0)
                            {
                                myCmd = new SqlCommand(sql, DBConnection.conn);
                                myCmd.Parameters.Add("@Sno", SqlDbType.NVarChar).Value = table2.Tables[0].Rows[i]["学号"].ToString().Trim();
                                myCmd.Parameters.Add("@XQ", SqlDbType.NVarChar).Value = table2.Tables[0].Rows[i]["学期"].ToString().Trim();
                                myCmd.Parameters.Add("@YJF", SqlDbType.NVarChar).Value = Convert.ToInt32(table2.Tables[0].Rows[i]["已缴费"].ToString().Trim());
                                myCmd.Parameters.Add("@QF", SqlDbType.NVarChar).Value = Convert.ToInt32(table2.Tables[0].Rows[i]["欠费"].ToString().Trim());
                                myCmd.Parameters.Add("@JL", SqlDbType.NVarChar).Value = table2.Tables[0].Rows[i]["奖励"].ToString().Trim();
                                myCmd.Parameters.Add("@CF", SqlDbType.NVarChar).Value = table2.Tables[0].Rows[i]["处分"].ToString().Trim();
                                myCmd.ExecuteNonQuery();
                            }
                            else
                            {
                                listBox1.Items.Add("第" + (i + 1) + "条记录添加失败，原因：不存在该学生");
                                continue;
                            }
                        }
                        catch (Exception ex)
                        {
                            listBox1.Items.Add("第" + (i + 1) + "条记录添加失败，错误：" + ex.Message);
                            continue;
                        }
                    }
                    if (i == table2.Tables[0].Rows.Count)
                    {
                        MessageBox.Show("批量录入学生学费、奖惩信息完成","提示",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        MessageBox.Show("第" + (i + 1) + "行添加失败");
                    }
                }
                else { MessageBox.Show("没有任何数据需要录入!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有录入任何数据!\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*查询相应学生的学费、奖惩信息*/
        private void btnSelectFRP_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (txtSnoFRP.Text != "")
                {
                    LoadTips6.Visible = false;
                    string selectFRP;
                    selectFRP = string.Format("select XX_DA.XH as '学号',XM as '姓名',XQ as '学期',XY as '学院',ZY as '专业',NJ as '年级',BB as '班别',YJF as '已缴费',QF as '欠费',JL as '奖励',CF as '处分'");
                    selectFRP += string.Format(" from XX_DA,XX_XFJC where XX_DA.XH='{0}' and XX_XFJC.XH='{0}';", txtSnoFRP.Text);
                    //dgvShow(selectFRP, dataGridView2);
                    sda1 = new SqlDataAdapter(selectFRP, DBConnection.conn);
                    SqlCommandBuilder scb = new SqlCommandBuilder(sda1);
                    dt1 = new System.Data.DataTable();
                    sda1.Fill(dt1);
                    dataGridView2.DataSource = dt1;
                }
                else
                {
                    LoadTips6.Text = "学号不能为空!";
                    LoadTips6.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        private void dataGridView2_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            isUpdate1 = true;
            dataGridView2[e.ColumnIndex, e.RowIndex].Style.ForeColor = Color.Red;
        }

        /*修改相应学生的学费、奖惩信息*/
        private void btnAlterFRP_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (dataGridView2.Rows.Count > 1)
                {
                    dataGridView2.EndEdit();
                    if (isUpdate1)
                    {
                        LoadTips6.Visible = false;
                        try
                        {
                            if (MessageBox.Show("确定要对学费、奖惩信息进行修改吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                sda1.Update(dt1);
                                isUpdate1 = false;
                                MessageBox.Show("修改学费、奖惩信息成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                btnSelectFRP_Click(sender, e);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        LoadTips6.Text = "没有进行任何的修改!";
                        LoadTips6.Visible = true;
                    }
                }
                else
                {
                    LoadTips6.Text = "没有要修改的数据!";
                    LoadTips6.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有修改任何数据!\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*校历导入浏览Excel文件并显示出文件的内容*/
        private void OpenFileDialog_Click(object sender, EventArgs e)
        {
            try
            {
                table3 = new DataSet();
                OpenFile(dataGridView5, table3, textBox3);
                if (dataGridView5.Rows.Count > 0)
                {
                    if (dataGridView5.Columns[0].HeaderText.Trim() != "学期" || dataGridView5.Columns[1].HeaderText.Trim() != "周数"
                        || dataGridView5.Columns[2].HeaderText.Trim() != "星期一" || dataGridView5.Columns[3].HeaderText.Trim() != "星期二"
                        || dataGridView5.Columns[4].HeaderText.Trim() != "星期三" || dataGridView5.Columns[5].HeaderText.Trim() != "星期四"
                        || dataGridView5.Columns[6].HeaderText.Trim() != "星期五" || dataGridView5.Columns[7].HeaderText.Trim() != "星期六"
                        || dataGridView5.Columns[8].HeaderText.Trim() != "星期日" || dataGridView5.Columns[9].HeaderText.Trim() != "备注")
                    {
                        MessageBox.Show("Excel表格格式不正确，请参照标准表格格式!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        table3.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*导入校历*/
        private void ImportXL_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (table3.Tables[0].Rows.Count > 0)
                {
                    string sql = "";
                    SqlCommand myCmd = null;
                    int i = 0;
                    listBox3.Items.Clear();
                    for (; i < table3.Tables[0].Rows.Count; i++)
                    {
                        sql = string.Format("insert into XX_XL(XQ,ZS,MON,TUES,WED,THURS,FRI,SAT,SUN,BZ) values (@XQ,@ZS,@Mon,@Tues,@Wed,@Thurs,@Fri,@Sat,@Sun,@BZ)");
                        try
                        {
                            myCmd = new SqlCommand(sql, DBConnection.conn);
                            myCmd.Parameters.Add("@XQ", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["学期"].ToString().Trim();
                            myCmd.Parameters.Add("@ZS", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["周数"].ToString().Trim();
                            myCmd.Parameters.Add("@Mon",SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期一"].ToString().Trim();
                            myCmd.Parameters.Add("@Tues",SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期二"].ToString().Trim();
                            myCmd.Parameters.Add("@Wed", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期三"].ToString().Trim();
                            myCmd.Parameters.Add("@Thurs",SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期四"].ToString().Trim();
                            myCmd.Parameters.Add("@Fri", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期五"].ToString().Trim();
                            myCmd.Parameters.Add("@Sat", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期六"].ToString().Trim();
                            myCmd.Parameters.Add("@Sun", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["星期日"].ToString().Trim();
                            myCmd.Parameters.Add("@BZ", SqlDbType.NVarChar).Value = table3.Tables[0].Rows[i]["备注"].ToString().Trim();
                            myCmd.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            listBox3.Items.Add("第" + (i + 1) + "条记录添加失败，错误：" + ex.Message);
                            continue;
                        }
                    }
                    if (i == table3.Tables[0].Rows.Count)
                    {
                        MessageBox.Show("导入校历完成","提示",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        MessageBox.Show("第" + (i + 1) + "行添加失败");
                    }
                }
                else { MessageBox.Show("没有任何数据需要导入!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有导入任何数据!\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*查询校历*/
        private void SelectXL_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (comboBox4.Text != "")
                {
                    LoadTips7.Visible = false;
                    string selectXL;
                    selectXL = string.Format("select XQ as '学期', ZS as '周数',MON as '星期一',TUES as '星期二',WED as '星期三', THURS as '星期四',FRI as '星期五',");
                    selectXL += string.Format("SAT as '星期六',SUN as '星期日',BZ as '备注' from XX_XL where XQ='{0}';", comboBox4.Text);
                    sda2 = new SqlDataAdapter(selectXL,DBConnection.conn);
                    SqlCommandBuilder scb = new SqlCommandBuilder(sda2);
                    dt2 = new System.Data.DataTable();
                    sda2.Fill(dt2);
                    dataGridView5.DataSource =dt2 ;
                }
                else
                {
                    LoadTips7.Text = "学期不能为空!";
                    LoadTips7.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        private void dataGridView5_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            isUpdate2 = true;
            dataGridView5[e.ColumnIndex, e.RowIndex].Style.ForeColor = Color.Red;
        }

        /*修改校历*/
        private void AlterXL_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if(dataGridView5.Rows.Count>1)
                {
                    dataGridView5.EndEdit();
                    if (isUpdate2)
                    {
                        LoadTips7.Visible = false;
                        try
                        {
                            if (MessageBox.Show("确定要对校历进行修改吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                            {
                                sda2.Update(dt2);
                                isUpdate2 = false;
                                MessageBox.Show("更新校历成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                DBConnection.conn.Close();
                                SelectXL_Click(sender, e);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        LoadTips7.Text = "没有进行任何的修改!";
                        LoadTips7.Visible = true; 
                    }
                }
                else
                { 
                    LoadTips7.Text = "没有要修改的数据!";
                    LoadTips7.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有修改任何数据!\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*课程表导入浏览Excel文件并显示出文件的内容*/
        private void OpenFileDia2_Click(object sender, EventArgs e)
        {
            try
            {
                table4 = new DataSet();
                OpenFile(dataGridView6, table4, textBox2);
                if (dataGridView6.Rows.Count > 0)
                {
                    if (dataGridView6.Columns[0].HeaderText.Trim() != "课程号" || dataGridView6.Columns[1].HeaderText.Trim() != "课程名"
                        || dataGridView6.Columns[2].HeaderText.Trim() != "授课教师" || dataGridView6.Columns[3].HeaderText.Trim() != "学分")
                    {
                        MessageBox.Show("Excel表格格式不正确，请参照标准表格格式!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                        table4.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*批量导入课程表*/
        private void ImportCourse_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (table4.Tables[0].Rows.Count > 0)
                {
                    string sql = "";
                    SqlCommand myCmd = null;
                    int i = 0;
                    listBox4.Items.Clear();
                    for (; i < table4.Tables[0].Rows.Count; i++)
                    {
                        string sql1 = string.Format("select count(*) from XX_KC where KCH=@Cno");
                        SqlCommand sqlselect = new SqlCommand(sql1, DBConnection.conn);
                        sqlselect.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = table4.Tables[0].Rows[i]["课程号"].ToString().Trim();
                        int j= (int)sqlselect.ExecuteScalar();
                        if (j == 0)
                        {
                            sql = string.Format("insert into XX_KC(KCH,KCM,SKJS,XF) values (@Cno,@Cname,@Techer,@Credit)");
                            try
                            {
                                myCmd = new SqlCommand(sql, DBConnection.conn);
                                myCmd.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = table4.Tables[0].Rows[i]["课程号"].ToString().Trim();
                                myCmd.Parameters.Add("@Cname", SqlDbType.NVarChar).Value = table4.Tables[0].Rows[i]["课程名"].ToString().Trim();
                                myCmd.Parameters.Add("@Techer", SqlDbType.NVarChar).Value = table4.Tables[0].Rows[i]["授课教师"].ToString().Trim();
                                myCmd.Parameters.Add("@Credit", SqlDbType.NVarChar).Value = table4.Tables[0].Rows[i]["学分"].ToString().Trim();
                                myCmd.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                listBox4.Items.Add("第" + (i + 1) + "条记录添加失败，错误：" + ex.Message);
                                continue;
                            }
                        }   
                        else
                        {                            
                            listBox4.Items.Add("第" + (i + 1) + "条记录添加失败，错误：已存在该记录!");
                            continue;
                        }
                    }
                    if (i == table4.Tables[0].Rows.Count)
                    {
                        MessageBox.Show("批量导入课程表完成", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        MessageBox.Show("第" + (i + 1) + "行添加失败");
                    }
                }
                else { MessageBox.Show("没有任何数据需要导入!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); }
            }
            catch (Exception ex)
            {
                MessageBox.Show("没有导入任何数据!\n" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*单项添加课程表*/
        private void AddCourse_Click(object sender, EventArgs e)
        {
            DBConnection.conn.Open();
            try
            {
                LoadTips3.Visible = false;
                if (txtCno1.Text != "" && txtCname.Text != "" && txtCtecher.Text != "" && txtCredit.Text != "")
                {
                    string sql = string.Format("select count(*) from XX_KC where KCH=@Cno");
                    SqlCommand sqlselect = new SqlCommand(sql, DBConnection.conn);
                    sqlselect.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno1.Text;
                    int i = (int)sqlselect.ExecuteScalar();
                    if (i == 0)
                    {
                        string sqlInsert, selectCourse;
                        sqlInsert = "insert into XX_KC(KCH,KCM,SKJS,XF) values (@Cno,@Cname,@Techer,@Credit)";
                        selectCourse = string.Format("select KCH as '课程号',KCM as '课程名',SKJS as'授课教师',XF as'学分'");
                        selectCourse += string.Format("from XX_KC where KCH='{0}'", txtCno1.Text);
                        SqlCommand sqlcmd = new SqlCommand(sqlInsert, DBConnection.conn);
                        sqlcmd.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno1.Text;
                        sqlcmd.Parameters.Add("@Cname", SqlDbType.NVarChar).Value = txtCname.Text;
                        sqlcmd.Parameters.Add("@Techer", SqlDbType.NVarChar).Value = txtCtecher.Text;
                        sqlcmd.Parameters.Add("@Credit", SqlDbType.NVarChar).Value = txtCredit.Text;
                        int j = sqlcmd.ExecuteNonQuery();
                        if (j > 0)
                        {
                            LoadTips3.Text = "添加成功!";
                            LoadTips3.Visible = true;
                            dgvShow(selectCourse, dataGridView6);
                        }
                    }
                    else
                    {
                        LoadTips3.Text = "已存在该课程号的相关信息!";
                        LoadTips3.Visible = true;
                    }
                }
                else
                {
                    LoadTips3.Text = "请填完整所有信息!";
                    LoadTips3.Visible = true;
                }     
            }
            catch (Exception ex)
            {
                MessageBox.Show("添加失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*修改课程表*/
        private void AlterCourse_Click(object sender, EventArgs e)
        {
            DBConnection.conn.Open();
            try
            {
                LoadTips3.Visible = false;
                if (txtCno1.Text != "" && txtCname.Text != "" && txtCtecher.Text != "" && txtCredit.Text != "")
                {
                    if (MessageBox.Show("是否要进行修改？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
                    {
                        string sql = string.Format("select count(*) from XX_KC where KCH=@Cno");
                        SqlCommand sqlselect = new SqlCommand(sql, DBConnection.conn);
                        sqlselect.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno1.Text;
                        int i = (int)sqlselect.ExecuteScalar();
                        if (i > 0)
                        {
                            string sqlAlter, selectCourse;
                            sqlAlter = string.Format("update XX_KC set KCM=@Cname,SKJS=@Techer,XF=@Credit where KCH=@Cno");
                            selectCourse = string.Format("select KCH as '课程号',KCM as '课程名',SKJS as '授课教师',XF as '学分'");
                            selectCourse += string.Format("from XX_KC where KCH='{0}'", txtCno1.Text);
                            SqlCommand sqlcmd = new SqlCommand(sqlAlter, DBConnection.conn);
                            sqlcmd.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno1.Text;
                            sqlcmd.Parameters.Add("@Cname", SqlDbType.NVarChar).Value = txtCname.Text;
                            sqlcmd.Parameters.Add("@Techer", SqlDbType.NVarChar).Value = txtCtecher.Text;
                            sqlcmd.Parameters.Add("@Credit", SqlDbType.NVarChar).Value = txtCredit.Text;
                            int j = sqlcmd.ExecuteNonQuery();
                            if (j > 0)
                            {
                                MessageBox.Show("修改成功!", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                                dgvShow(selectCourse, dataGridView6);
                            }
                        }
                        else
                        {
                            LoadTips3.Text = "不存在此课程!";
                            LoadTips3.Visible = true;
                        }
                    }
                }
                else 
                {
                    LoadTips3.Text = "请填完整所有信息项!";
                    LoadTips3.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("修改失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*课程表查询*/
        private void SelectCourse_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                LoadTips5.Visible = false;
                if (txtCno3.Text != "")
                {
                    string sql = string.Format("select count(*) from XX_KC,XX_XSKCB where XX_KC.KCH=@Cno and XX_XSKCB.KCH=@Cno");
                    SqlCommand sqlselect = new SqlCommand(sql, DBConnection.conn);
                    sqlselect.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno3.Text;
                    int i = (int)sqlselect.ExecuteScalar();
                    if (i > 0)
                    {
                        string selectCourse;
                        selectCourse = string.Format("select XX_KC.KCH as '课程号',KCM as '课程名',SKJS as '授课教师',XF as'学分',ZY as '专业',NJ as '年级',XQ as '学期'");
                        selectCourse += string.Format(" from XX_KC,XX_XSKCB where XX_KC.KCH='{0}' and XX_XSKCB.KCH='{0}'", txtCno3.Text);
                        dgvShow(selectCourse, dataGridView6);
                    }
                    else
                    {
                        string sql1 = string.Format("select count(*) from XX_KC where KCH=@Cno");
                        SqlCommand sqlselect1 = new SqlCommand(sql1, DBConnection.conn);
                        sqlselect1.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno3.Text;
                        int j = (int)sqlselect1.ExecuteScalar();
                        if (j > 0)
                        {
                            string selectCourse;
                            selectCourse = string.Format("select KCH as '课程号',KCM as '课程名',SKJS as'授课教师',XF as'学分'");
                            selectCourse += string.Format("from XX_KC where KCH='{0}'", txtCno3.Text);
                            dgvShow(selectCourse, dataGridView6);
                        }
                        else
                        {
                            LoadTips5.Text = "不存在该课程的相关信息!";
                            LoadTips5.Visible = true;
                        }
                    }
                }
                else
                {
                    LoadTips5.Text = "课程号不能为空!";
                    LoadTips5.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*导出课程表*/
        private void ExportCourse_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView6.Rows.Count == 1)
                {
                    MessageBox.Show("没有要导出的数据!", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                ImportFile(dataGridView6);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误提示");
            }
        }

        /*进行课程分配*/
        private void AddCourseDis_Click(object sender, EventArgs e)
        {
            DBConnection.conn.Open();
            try
            {
                LoadTips4.Visible = false;
                if (txtCno2.Text != "" && txtCmajor.Text != "" && txtCgrade.Text != "" && comboBox5.Text != "")
                {
                    string sql = string.Format("select count(*) from XX_XSKCB where KCH=@Cno and ZY=@Major and NJ=@Grade and XQ=@Term");
                    SqlCommand sqlselect = new SqlCommand(sql, DBConnection.conn);
                    sqlselect.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno2.Text;
                    sqlselect.Parameters.Add("@Major", SqlDbType.NVarChar).Value = txtCmajor.Text;
                    sqlselect.Parameters.Add("@Grade", SqlDbType.NVarChar).Value = txtCgrade.Text;
                    sqlselect.Parameters.Add("@Term", SqlDbType.NVarChar).Value = comboBox5.Text;
                    int i = (int)sqlselect.ExecuteScalar();
                    if (i == 0)
                    {
                        string sql1 = string.Format("select count(*) from XX_KC where KCH=@Cno");
                        SqlCommand sqlselect1 = new SqlCommand(sql1, DBConnection.conn);
                        sqlselect1.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno2.Text;
                        int j = (int)sqlselect1.ExecuteScalar();
                        if (j > 0)
                        {
                            string sqlInsert, selectCourseDis;
                            sqlInsert = "insert into XX_XSKCB(KCH,ZY,NJ,XQ) values (@Cno,@Major,@Grade,@Term)";
                            selectCourseDis = string.Format("select XX_KC.KCH as '课程号',KCM as '课程名',ZY as'专业',NJ as'年级',XQ as '学期'");
                            selectCourseDis += string.Format("from XX_KC,XX_XSKCB where XX_KC.KCH='{0}' and XX_XSKCB.KCH='{0}' ", txtCno2.Text);
                            selectCourseDis += string.Format("and ZY='{0}' and NJ='{1}' and XQ='{2}'", txtCmajor.Text, txtCgrade.Text, comboBox5.Text);
                            SqlCommand sqlcmd = new SqlCommand(sqlInsert, DBConnection.conn);
                            sqlcmd.Parameters.Add("@Cno", SqlDbType.NVarChar).Value = txtCno2.Text;
                            sqlcmd.Parameters.Add("@Major", SqlDbType.NVarChar).Value = txtCmajor.Text;
                            sqlcmd.Parameters.Add("@Grade", SqlDbType.NVarChar).Value = txtCgrade.Text;
                            sqlcmd.Parameters.Add("@Term", SqlDbType.NVarChar).Value = comboBox5.Text;
                            int k = sqlcmd.ExecuteNonQuery();
                            if (k > 0)
                            {
                                LoadTips4.Text = "分配成功!";
                                LoadTips4.Visible = true;
                                dgvShow(selectCourseDis, dataGridView6);
                            }
                        }
                        else
                        {
                            LoadTips4.Text = "不存在该课程!";
                            LoadTips4.Visible = true;
                        }
                    }
                    else
                    {
                        LoadTips4.Text = "已存在该分配!";
                        LoadTips4.Visible = true;
                    }
                }
                else
                {
                    LoadTips4.Text = "请填完整所有信息!";
                    LoadTips4.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("添加失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*链接帮助文档*/
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                linkLabel1.LinkVisited = true;
                string path = Path.GetFullPath(@"..\..\Help.doc");
                System.Diagnostics.Process.Start(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show("打开链接失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*链接帮助文档*/
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                linkLabel2.LinkVisited = true;
                string path = Path.GetFullPath(@"..\..\Help.doc");
                System.Diagnostics.Process.Start(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show("打开链接失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*链接帮助文档*/
        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                linkLabel3.LinkVisited = true;
                string path = Path.GetFullPath(@"..\..\Help.doc");
                System.Diagnostics.Process.Start(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show("打开链接失败!\n" + ex.Message, "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*退出程序*/
        private void Exit(object sender, FormClosedEventArgs e)
        {
            this.Owner.Dispose();
        }
    }
}
