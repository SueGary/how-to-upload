﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    //连接字符串类，调用时直接Constring.connectionString
    class DBConnection
    {
        //public static string connectionString = "server=localhost;uid=sa;pwd=123;database=SXXXGL";
        public static string sql = "data source=localhost;database=SXXXGL;integrated security=true;";
        public static SqlConnection conn = new SqlConnection(sql);
    }
    //学生登录时记录学生学号，方便各个功能的界面直接调用查询相关信息
    class Stuid
    {
        public static string StuID;
        public static string StuStatus;
    }
    //管理员登录时记录管理员工号，方便各个功能的界面直接调用查询相关信a息
    class GuanliYuan
    {
        public static string GuanID;
        public static string AdStatus;
    }
}
