﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        /*进行登录*/
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (radioButton1.Checked)
                {
                    if (UserName.Text == "")
                    {
                        MessageBox.Show("用户名不能为空!", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@UserStatus and YHM = @UserName and PWD = @pwd", DBConnection.conn);
                        cmd.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = radioButton1.Text;
                        cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                        cmd.Parameters.Add("@pwd", SqlDbType.NVarChar).Value = pwd.Text;
                        SqlDataReader r = cmd.ExecuteReader();
                        if (r.Read())
                        {
                            r.Close();
                            StudentModule f = new StudentModule();
                            f.Owner = this;
                            Stuid.StuID = UserName.Text;
                            Stuid.StuStatus = radioButton1.Text;
                            f.Show();
                            this.Hide();
                        }
                        else
                        {
                            r.Close();
                            MessageBox.Show("不存在此用户或密码错误！","错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
                            pwd.Text = "";
                        }
                    }
                }
                if (radioButton2.Checked)
                {
                    if (UserName.Text == "")
                    {
                        MessageBox.Show("用户名不能为空!","错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@UserStatus and YHM = @UserName and PWD = @pwd", DBConnection.conn );
                        cmd.Parameters.Add("@UserStatus", SqlDbType.NVarChar).Value = radioButton2.Text;
                        cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.Text;
                        cmd.Parameters.Add("@pwd", SqlDbType.NVarChar).Value = pwd.Text;
                        SqlDataReader r = cmd.ExecuteReader();
                        if (r.Read())
                        {
                            r.Close();
                            AdministratorModule g = new AdministratorModule();
                            g.Owner = this;
                            GuanliYuan.GuanID = UserName.Text;
                            GuanliYuan.AdStatus = radioButton2.Text;
                            g.Show();
                            this.Hide();
                        }
                        else
                        {
                            r.Close();
                            MessageBox.Show("不存在此用户或密码错误！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            pwd.Text = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        private void UserName_TextChanged(object sender, EventArgs e)
        {
            LoadTip.Visible = false;
        }

        private void pwd_TextChanged(object sender, EventArgs e)
        {
            LoadTip.Visible = false;
        }

        /*退出登录*/
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UsNam_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 38) { btnExit.Focus(); }
            if (e.KeyValue == 40) { pwd.Focus(); }
        }

        private void Pwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue ==38) { UserName.Focus(); }
            if (e.KeyValue ==40) { btnLogIn.Focus(); }
        }
    }
}
