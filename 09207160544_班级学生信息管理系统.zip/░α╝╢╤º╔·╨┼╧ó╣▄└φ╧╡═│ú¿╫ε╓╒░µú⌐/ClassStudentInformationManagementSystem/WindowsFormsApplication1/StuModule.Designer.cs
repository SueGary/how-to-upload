﻿namespace WindowsFormsApplication1
{
    partial class StudentModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentModule));
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.LoadTips2 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SelectXL = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.SelectCourse = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Glade = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.MobilePhoneNum = new System.Windows.Forms.Label();
            this.DormPhoneNum = new System.Windows.Forms.Label();
            this.HomePhoneNum = new System.Windows.Forms.Label();
            this.DormAddr = new System.Windows.Forms.Label();
            this.PostalCode = new System.Windows.Forms.Label();
            this.NowFamAddr = new System.Windows.Forms.Label();
            this.FamilyAddr = new System.Windows.Forms.Label();
            this.ShengYuanD = new System.Windows.Forms.Label();
            this.ExamineID = new System.Windows.Forms.Label();
            this.IDNumber = new System.Windows.Forms.Label();
            this.Birthdate = new System.Windows.Forms.Label();
            this.ZhengZhiMM = new System.Windows.Forms.Label();
            this.JiGuan = new System.Windows.Forms.Label();
            this.MingZhu = new System.Windows.Forms.Label();
            this.XueZhi = new System.Windows.Forms.Label();
            this.EntryTime = new System.Windows.Forms.Label();
            this.StudentCatogary = new System.Windows.Forms.Label();
            this.Class = new System.Windows.Forms.Label();
            this.Professal = new System.Windows.Forms.Label();
            this.Academy = new System.Windows.Forms.Label();
            this.School = new System.Windows.Forms.Label();
            this.UsedName = new System.Windows.Forms.Label();
            this.Sex = new System.Windows.Forms.Label();
            this.StudentName = new System.Windows.Forms.Label();
            this.StudentId = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.LoadTips1 = new System.Windows.Forms.Label();
            this.SureNewPwd = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.NewPwd = new System.Windows.Forms.TextBox();
            this.UsedPwd = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.LoadTips2);
            this.tabPage7.Controls.Add(this.label2);
            this.tabPage7.Controls.Add(this.SelectXL);
            this.tabPage7.Controls.Add(this.comboBox1);
            this.tabPage7.Controls.Add(this.dataGridView4);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(671, 481);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "校历";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // LoadTips2
            // 
            this.LoadTips2.AutoSize = true;
            this.LoadTips2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips2.ForeColor = System.Drawing.Color.Red;
            this.LoadTips2.Location = new System.Drawing.Point(349, 10);
            this.LoadTips2.Name = "LoadTips2";
            this.LoadTips2.Size = new System.Drawing.Size(56, 16);
            this.LoadTips2.TabIndex = 4;
            this.LoadTips2.Text = "label3";
            this.LoadTips2.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.BlueViolet;
            this.label2.Location = new System.Drawing.Point(32, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "学   期：";
            // 
            // SelectXL
            // 
            this.SelectXL.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SelectXL.Location = new System.Drawing.Point(470, 4);
            this.SelectXL.Name = "SelectXL";
            this.SelectXL.Size = new System.Drawing.Size(166, 29);
            this.SelectXL.TabIndex = 2;
            this.SelectXL.Text = "查  询";
            this.SelectXL.UseVisualStyleBackColor = true;
            this.SelectXL.Click += new System.EventHandler(this.SelectXL_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2009-2010学年第一学期",
            "2009-2010学年第二学期",
            "2010-2011学年第一学期",
            "2010-2011学年第二学期",
            "2011-2012学年第一学期",
            "2011-2012学年第二学期",
            "2012-2013学年第一学期",
            "2012-2013学年第二学期"});
            this.comboBox1.Location = new System.Drawing.Point(106, 8);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(225, 20);
            this.comboBox1.TabIndex = 1;
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(3, 36);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowTemplate.Height = 23;
            this.dataGridView4.Size = new System.Drawing.Size(662, 439);
            this.dataGridView4.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(671, 481);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "学费奖惩查询";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(0, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(668, 475);
            this.dataGridView3.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(671, 481);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "成绩查询";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(671, 476);
            this.dataGridView2.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.dataGridView5);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(671, 481);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "我的课表";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.SelectCourse);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.ForeColor = System.Drawing.Color.Gray;
            this.groupBox1.Location = new System.Drawing.Point(8, 389);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(656, 86);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "课程查询";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "2009-2010学年第一学期",
            "2009-2010学年第二学期",
            "2010-2011学年第一学期",
            "2010-2011学年第二学期",
            "2011-2012学年第一学期",
            "2011-2012学年第二学期",
            "2012-2013学年第一学期",
            "2012-2013学年第二学期"});
            this.comboBox2.Location = new System.Drawing.Point(174, 35);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(184, 20);
            this.comboBox2.TabIndex = 3;
            // 
            // SelectCourse
            // 
            this.SelectCourse.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SelectCourse.Location = new System.Drawing.Point(433, 30);
            this.SelectCourse.Name = "SelectCourse";
            this.SelectCourse.Size = new System.Drawing.Size(150, 29);
            this.SelectCourse.TabIndex = 2;
            this.SelectCourse.Text = "查  询";
            this.SelectCourse.UseVisualStyleBackColor = true;
            this.SelectCourse.Click += new System.EventHandler(this.SelectCourse_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(115, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "学  期：";
            // 
            // dataGridView5
            // 
            this.dataGridView5.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(8, 6);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowTemplate.Height = 23;
            this.dataGridView5.Size = new System.Drawing.Size(656, 377);
            this.dataGridView5.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(665, 478);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Glade);
            this.tabPage1.Controls.Add(this.label57);
            this.tabPage1.Controls.Add(this.MobilePhoneNum);
            this.tabPage1.Controls.Add(this.DormPhoneNum);
            this.tabPage1.Controls.Add(this.HomePhoneNum);
            this.tabPage1.Controls.Add(this.DormAddr);
            this.tabPage1.Controls.Add(this.PostalCode);
            this.tabPage1.Controls.Add(this.NowFamAddr);
            this.tabPage1.Controls.Add(this.FamilyAddr);
            this.tabPage1.Controls.Add(this.ShengYuanD);
            this.tabPage1.Controls.Add(this.ExamineID);
            this.tabPage1.Controls.Add(this.IDNumber);
            this.tabPage1.Controls.Add(this.Birthdate);
            this.tabPage1.Controls.Add(this.ZhengZhiMM);
            this.tabPage1.Controls.Add(this.JiGuan);
            this.tabPage1.Controls.Add(this.MingZhu);
            this.tabPage1.Controls.Add(this.XueZhi);
            this.tabPage1.Controls.Add(this.EntryTime);
            this.tabPage1.Controls.Add(this.StudentCatogary);
            this.tabPage1.Controls.Add(this.Class);
            this.tabPage1.Controls.Add(this.Professal);
            this.tabPage1.Controls.Add(this.Academy);
            this.tabPage1.Controls.Add(this.School);
            this.tabPage1.Controls.Add(this.UsedName);
            this.tabPage1.Controls.Add(this.Sex);
            this.tabPage1.Controls.Add(this.StudentName);
            this.tabPage1.Controls.Add(this.StudentId);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.label32);
            this.tabPage1.Controls.Add(this.label33);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(671, 481);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "个人档案";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Glade
            // 
            this.Glade.AutoSize = true;
            this.Glade.Location = new System.Drawing.Point(103, 263);
            this.Glade.Name = "Glade";
            this.Glade.Size = new System.Drawing.Size(47, 12);
            this.Glade.TabIndex = 119;
            this.Glade.Text = "label56";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label57.Location = new System.Drawing.Point(43, 263);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(65, 12);
            this.label57.TabIndex = 118;
            this.label57.Text = "年    级：";
            // 
            // MobilePhoneNum
            // 
            this.MobilePhoneNum.AutoSize = true;
            this.MobilePhoneNum.Location = new System.Drawing.Point(414, 437);
            this.MobilePhoneNum.Name = "MobilePhoneNum";
            this.MobilePhoneNum.Size = new System.Drawing.Size(47, 12);
            this.MobilePhoneNum.TabIndex = 117;
            this.MobilePhoneNum.Text = "label55";
            // 
            // DormPhoneNum
            // 
            this.DormPhoneNum.AutoSize = true;
            this.DormPhoneNum.Location = new System.Drawing.Point(414, 403);
            this.DormPhoneNum.Name = "DormPhoneNum";
            this.DormPhoneNum.Size = new System.Drawing.Size(47, 12);
            this.DormPhoneNum.TabIndex = 116;
            this.DormPhoneNum.Text = "label54";
            // 
            // HomePhoneNum
            // 
            this.HomePhoneNum.AutoSize = true;
            this.HomePhoneNum.Location = new System.Drawing.Point(414, 368);
            this.HomePhoneNum.Name = "HomePhoneNum";
            this.HomePhoneNum.Size = new System.Drawing.Size(47, 12);
            this.HomePhoneNum.TabIndex = 115;
            this.HomePhoneNum.Text = "label50";
            // 
            // DormAddr
            // 
            this.DormAddr.AutoSize = true;
            this.DormAddr.Location = new System.Drawing.Point(414, 330);
            this.DormAddr.Name = "DormAddr";
            this.DormAddr.Size = new System.Drawing.Size(47, 12);
            this.DormAddr.TabIndex = 114;
            this.DormAddr.Text = "label49";
            // 
            // PostalCode
            // 
            this.PostalCode.AutoSize = true;
            this.PostalCode.Location = new System.Drawing.Point(414, 297);
            this.PostalCode.Name = "PostalCode";
            this.PostalCode.Size = new System.Drawing.Size(47, 12);
            this.PostalCode.TabIndex = 113;
            this.PostalCode.Text = "label48";
            // 
            // NowFamAddr
            // 
            this.NowFamAddr.AutoSize = true;
            this.NowFamAddr.Location = new System.Drawing.Point(414, 263);
            this.NowFamAddr.Name = "NowFamAddr";
            this.NowFamAddr.Size = new System.Drawing.Size(47, 12);
            this.NowFamAddr.TabIndex = 112;
            this.NowFamAddr.Text = "label47";
            // 
            // FamilyAddr
            // 
            this.FamilyAddr.AutoSize = true;
            this.FamilyAddr.Location = new System.Drawing.Point(414, 229);
            this.FamilyAddr.Name = "FamilyAddr";
            this.FamilyAddr.Size = new System.Drawing.Size(47, 12);
            this.FamilyAddr.TabIndex = 111;
            this.FamilyAddr.Text = "label46";
            // 
            // ShengYuanD
            // 
            this.ShengYuanD.AutoSize = true;
            this.ShengYuanD.Location = new System.Drawing.Point(414, 197);
            this.ShengYuanD.Name = "ShengYuanD";
            this.ShengYuanD.Size = new System.Drawing.Size(47, 12);
            this.ShengYuanD.TabIndex = 110;
            this.ShengYuanD.Text = "label45";
            // 
            // ExamineID
            // 
            this.ExamineID.AutoSize = true;
            this.ExamineID.Location = new System.Drawing.Point(414, 167);
            this.ExamineID.Name = "ExamineID";
            this.ExamineID.Size = new System.Drawing.Size(47, 12);
            this.ExamineID.TabIndex = 109;
            this.ExamineID.Text = "label44";
            // 
            // IDNumber
            // 
            this.IDNumber.AutoSize = true;
            this.IDNumber.Location = new System.Drawing.Point(414, 132);
            this.IDNumber.Name = "IDNumber";
            this.IDNumber.Size = new System.Drawing.Size(47, 12);
            this.IDNumber.TabIndex = 108;
            this.IDNumber.Text = "label43";
            // 
            // Birthdate
            // 
            this.Birthdate.AutoSize = true;
            this.Birthdate.Location = new System.Drawing.Point(414, 94);
            this.Birthdate.Name = "Birthdate";
            this.Birthdate.Size = new System.Drawing.Size(47, 12);
            this.Birthdate.TabIndex = 107;
            this.Birthdate.Text = "label42";
            // 
            // ZhengZhiMM
            // 
            this.ZhengZhiMM.AutoSize = true;
            this.ZhengZhiMM.Location = new System.Drawing.Point(414, 64);
            this.ZhengZhiMM.Name = "ZhengZhiMM";
            this.ZhengZhiMM.Size = new System.Drawing.Size(47, 12);
            this.ZhengZhiMM.TabIndex = 106;
            this.ZhengZhiMM.Text = "label41";
            // 
            // JiGuan
            // 
            this.JiGuan.AutoSize = true;
            this.JiGuan.Location = new System.Drawing.Point(414, 34);
            this.JiGuan.Name = "JiGuan";
            this.JiGuan.Size = new System.Drawing.Size(47, 12);
            this.JiGuan.TabIndex = 105;
            this.JiGuan.Text = "label40";
            // 
            // MingZhu
            // 
            this.MingZhu.AutoSize = true;
            this.MingZhu.Location = new System.Drawing.Point(103, 437);
            this.MingZhu.Name = "MingZhu";
            this.MingZhu.Size = new System.Drawing.Size(47, 12);
            this.MingZhu.TabIndex = 104;
            this.MingZhu.Text = "label39";
            // 
            // XueZhi
            // 
            this.XueZhi.AutoSize = true;
            this.XueZhi.Location = new System.Drawing.Point(103, 403);
            this.XueZhi.Name = "XueZhi";
            this.XueZhi.Size = new System.Drawing.Size(47, 12);
            this.XueZhi.TabIndex = 103;
            this.XueZhi.Text = "label37";
            // 
            // EntryTime
            // 
            this.EntryTime.AutoSize = true;
            this.EntryTime.Location = new System.Drawing.Point(103, 368);
            this.EntryTime.Name = "EntryTime";
            this.EntryTime.Size = new System.Drawing.Size(47, 12);
            this.EntryTime.TabIndex = 102;
            this.EntryTime.Text = "label36";
            // 
            // StudentCatogary
            // 
            this.StudentCatogary.AutoSize = true;
            this.StudentCatogary.Location = new System.Drawing.Point(103, 330);
            this.StudentCatogary.Name = "StudentCatogary";
            this.StudentCatogary.Size = new System.Drawing.Size(47, 12);
            this.StudentCatogary.TabIndex = 101;
            this.StudentCatogary.Text = "label35";
            // 
            // Class
            // 
            this.Class.AutoSize = true;
            this.Class.Location = new System.Drawing.Point(103, 297);
            this.Class.Name = "Class";
            this.Class.Size = new System.Drawing.Size(47, 12);
            this.Class.TabIndex = 100;
            this.Class.Text = "label34";
            // 
            // Professal
            // 
            this.Professal.AutoSize = true;
            this.Professal.Location = new System.Drawing.Point(103, 233);
            this.Professal.Name = "Professal";
            this.Professal.Size = new System.Drawing.Size(41, 12);
            this.Professal.TabIndex = 99;
            this.Professal.Text = "label8";
            // 
            // Academy
            // 
            this.Academy.AutoSize = true;
            this.Academy.Location = new System.Drawing.Point(103, 199);
            this.Academy.Name = "Academy";
            this.Academy.Size = new System.Drawing.Size(41, 12);
            this.Academy.TabIndex = 98;
            this.Academy.Text = "label7";
            // 
            // School
            // 
            this.School.AutoSize = true;
            this.School.Location = new System.Drawing.Point(103, 167);
            this.School.Name = "School";
            this.School.Size = new System.Drawing.Size(41, 12);
            this.School.TabIndex = 97;
            this.School.Text = "label6";
            // 
            // UsedName
            // 
            this.UsedName.AutoSize = true;
            this.UsedName.Location = new System.Drawing.Point(103, 132);
            this.UsedName.Name = "UsedName";
            this.UsedName.Size = new System.Drawing.Size(41, 12);
            this.UsedName.TabIndex = 96;
            this.UsedName.Text = "label5";
            // 
            // Sex
            // 
            this.Sex.AutoSize = true;
            this.Sex.Location = new System.Drawing.Point(103, 98);
            this.Sex.Name = "Sex";
            this.Sex.Size = new System.Drawing.Size(41, 12);
            this.Sex.TabIndex = 95;
            this.Sex.Text = "label4";
            // 
            // StudentName
            // 
            this.StudentName.AutoSize = true;
            this.StudentName.Location = new System.Drawing.Point(103, 64);
            this.StudentName.Name = "StudentName";
            this.StudentName.Size = new System.Drawing.Size(41, 12);
            this.StudentName.TabIndex = 94;
            this.StudentName.Text = "label3";
            // 
            // StudentId
            // 
            this.StudentId.AutoSize = true;
            this.StudentId.Location = new System.Drawing.Point(103, 34);
            this.StudentId.Name = "StudentId";
            this.StudentId.Size = new System.Drawing.Size(41, 12);
            this.StudentId.TabIndex = 93;
            this.StudentId.Text = "label2";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label25.Location = new System.Drawing.Point(352, 437);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 92;
            this.label25.Text = "手机号码：";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label24.Location = new System.Drawing.Point(352, 403);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 91;
            this.label24.Text = "宿舍电话：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label23.Location = new System.Drawing.Point(352, 368);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 90;
            this.label23.Text = "家庭电话：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label22.Location = new System.Drawing.Point(352, 330);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 89;
            this.label22.Text = "宿舍地址：";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label26.Location = new System.Drawing.Point(352, 297);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 12);
            this.label26.TabIndex = 88;
            this.label26.Text = "邮政编码：";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label27.Location = new System.Drawing.Point(340, 263);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(77, 12);
            this.label27.TabIndex = 87;
            this.label27.Text = "现家庭住址：";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label28.Location = new System.Drawing.Point(352, 229);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 12);
            this.label28.TabIndex = 86;
            this.label28.Text = "家庭住址：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label29.Location = new System.Drawing.Point(352, 197);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 85;
            this.label29.Text = "生 源 地：";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label30.Location = new System.Drawing.Point(352, 162);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 84;
            this.label30.Text = "考 生 号：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label31.Location = new System.Drawing.Point(352, 128);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 83;
            this.label31.Text = "身份证号：";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label32.Location = new System.Drawing.Point(352, 94);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 82;
            this.label32.Text = "出生年月：";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label33.Location = new System.Drawing.Point(352, 64);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(65, 12);
            this.label33.TabIndex = 81;
            this.label33.Text = "政治面貌：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(352, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 80;
            this.label1.Text = "籍    贯：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(43, 233);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 79;
            this.label9.Text = "专    业：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label10.Location = new System.Drawing.Point(43, 297);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 78;
            this.label10.Text = "班    别：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(43, 330);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 12);
            this.label11.TabIndex = 77;
            this.label11.Text = "学生类别：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(43, 368);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 76;
            this.label12.Text = "入学时间：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label14.Location = new System.Drawing.Point(43, 403);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 75;
            this.label14.Text = "学    制：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label15.Location = new System.Drawing.Point(43, 437);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 74;
            this.label15.Text = "民    族：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label16.Location = new System.Drawing.Point(43, 199);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 73;
            this.label16.Text = "学    院：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label17.Location = new System.Drawing.Point(43, 167);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 72;
            this.label17.Text = "学    校：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label18.Location = new System.Drawing.Point(43, 132);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 12);
            this.label18.TabIndex = 71;
            this.label18.Text = "曾 用 名：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label19.Location = new System.Drawing.Point(43, 98);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 12);
            this.label19.TabIndex = 70;
            this.label19.Text = "性    别：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label20.Location = new System.Drawing.Point(43, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 12);
            this.label20.TabIndex = 69;
            this.label20.Text = "姓    名：";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label21.Location = new System.Drawing.Point(43, 34);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 68;
            this.label21.Text = "学    号：";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(423, 43);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(0, 12);
            this.label38.TabIndex = 67;
            this.label38.Tag = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Black;
            this.label13.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label13.Location = new System.Drawing.Point(352, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 12);
            this.label13.TabIndex = 42;
            this.label13.Tag = "";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(679, 507);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 2;
            this.tabControl1.Tag = "";
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabContorl1_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage5.BackgroundImage")));
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(671, 481);
            this.tabPage5.TabIndex = 7;
            this.tabPage5.Text = "密码修改";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox4.Controls.Add(this.LoadTips1);
            this.groupBox4.Controls.Add(this.SureNewPwd);
            this.groupBox4.Controls.Add(this.label51);
            this.groupBox4.Controls.Add(this.NewPwd);
            this.groupBox4.Controls.Add(this.UsedPwd);
            this.groupBox4.Controls.Add(this.button20);
            this.groupBox4.Controls.Add(this.button21);
            this.groupBox4.Controls.Add(this.label52);
            this.groupBox4.Controls.Add(this.label53);
            this.groupBox4.ForeColor = System.Drawing.Color.Gray;
            this.groupBox4.Location = new System.Drawing.Point(-4, -10);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(679, 491);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "密码修改";
            // 
            // LoadTips1
            // 
            this.LoadTips1.AutoSize = true;
            this.LoadTips1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LoadTips1.ForeColor = System.Drawing.Color.Red;
            this.LoadTips1.Location = new System.Drawing.Point(211, 76);
            this.LoadTips1.Name = "LoadTips1";
            this.LoadTips1.Size = new System.Drawing.Size(76, 21);
            this.LoadTips1.TabIndex = 8;
            this.LoadTips1.Text = "label2";
            this.LoadTips1.Visible = false;
            // 
            // SureNewPwd
            // 
            this.SureNewPwd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SureNewPwd.Location = new System.Drawing.Point(287, 268);
            this.SureNewPwd.Name = "SureNewPwd";
            this.SureNewPwd.PasswordChar = '*';
            this.SureNewPwd.Size = new System.Drawing.Size(192, 21);
            this.SureNewPwd.TabIndex = 7;
            this.SureNewPwd.TextChanged += new System.EventHandler(this.SureNewPwd_TextChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.Color.BlueViolet;
            this.label51.Location = new System.Drawing.Point(222, 271);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(65, 12);
            this.label51.TabIndex = 6;
            this.label51.Text = "密码确认：";
            // 
            // NewPwd
            // 
            this.NewPwd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.NewPwd.Location = new System.Drawing.Point(287, 200);
            this.NewPwd.Name = "NewPwd";
            this.NewPwd.PasswordChar = '*';
            this.NewPwd.Size = new System.Drawing.Size(192, 21);
            this.NewPwd.TabIndex = 5;
            this.NewPwd.TextChanged += new System.EventHandler(this.NewPwd_TextChanged);
            // 
            // UsedPwd
            // 
            this.UsedPwd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UsedPwd.Location = new System.Drawing.Point(287, 129);
            this.UsedPwd.Name = "UsedPwd";
            this.UsedPwd.PasswordChar = '*';
            this.UsedPwd.Size = new System.Drawing.Size(192, 21);
            this.UsedPwd.TabIndex = 4;
            this.UsedPwd.TextChanged += new System.EventHandler(this.UsedPwd_TextChanged);
            // 
            // button20
            // 
            this.button20.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button20.Location = new System.Drawing.Point(404, 337);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 36);
            this.button20.TabIndex = 1;
            this.button20.Text = "密码重置";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button21.Location = new System.Drawing.Point(224, 337);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 36);
            this.button21.TabIndex = 0;
            this.button21.Text = "确认修改";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.ForeColor = System.Drawing.Color.BlueViolet;
            this.label52.Location = new System.Drawing.Point(222, 203);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(65, 12);
            this.label52.TabIndex = 3;
            this.label52.Text = "新 密 码：";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.ForeColor = System.Drawing.Color.BlueViolet;
            this.label53.Location = new System.Drawing.Point(222, 132);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(65, 12);
            this.label53.TabIndex = 2;
            this.label53.Text = "原 密 码：";
            // 
            // StudentModule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(680, 506);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "StudentModule";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "学生信息";
            this.Load += new System.EventHandler(this.StudentModule_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Exit);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label MobilePhoneNum;
        private System.Windows.Forms.Label DormPhoneNum;
        private System.Windows.Forms.Label HomePhoneNum;
        private System.Windows.Forms.Label DormAddr;
        private System.Windows.Forms.Label PostalCode;
        private System.Windows.Forms.Label NowFamAddr;
        private System.Windows.Forms.Label FamilyAddr;
        private System.Windows.Forms.Label ShengYuanD;
        private System.Windows.Forms.Label ExamineID;
        private System.Windows.Forms.Label IDNumber;
        private System.Windows.Forms.Label Birthdate;
        private System.Windows.Forms.Label ZhengZhiMM;
        private System.Windows.Forms.Label JiGuan;
        private System.Windows.Forms.Label MingZhu;
        private System.Windows.Forms.Label XueZhi;
        private System.Windows.Forms.Label EntryTime;
        private System.Windows.Forms.Label StudentCatogary;
        private System.Windows.Forms.Label Class;
        private System.Windows.Forms.Label Professal;
        private System.Windows.Forms.Label Academy;
        private System.Windows.Forms.Label School;
        private System.Windows.Forms.Label UsedName;
        private System.Windows.Forms.Label Sex;
        private System.Windows.Forms.Label StudentName;
        private System.Windows.Forms.Label StudentId;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox SureNewPwd;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox NewPwd;
        private System.Windows.Forms.TextBox UsedPwd;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label Glade;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label LoadTips1;
        private System.Windows.Forms.Button SelectXL;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LoadTips2;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SelectCourse;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;



    }
}