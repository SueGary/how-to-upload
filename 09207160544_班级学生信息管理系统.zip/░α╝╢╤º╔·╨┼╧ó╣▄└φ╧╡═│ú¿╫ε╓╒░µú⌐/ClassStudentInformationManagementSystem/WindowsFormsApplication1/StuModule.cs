﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class StudentModule : Form
    {
        public StudentModule()
        {
            InitializeComponent();
        }

        private void StudentModule_Load(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd1 = new SqlCommand("select * from XX_DA where XH = @StudentID",DBConnection.conn);
                cmd1.Parameters.Add("@StudentID",SqlDbType.NVarChar).Value = Convert.ToString(Stuid.StuID);
                SqlDataReader r1 = cmd1.ExecuteReader();
                if(r1.Read())
                {
                    StudentId.Text = Convert.ToString(r1["XH"]);
                    StudentName.Text = Convert.ToString(r1["XM"]);
                    Sex.Text = Convert.ToString(r1["XB"]);
                    UsedName.Text = Convert.ToString(r1["CYM"]);
                    School.Text = Convert.ToString(r1["XX"]);
                    Academy.Text = Convert.ToString(r1["XY"]);
                    Professal.Text = Convert.ToString(r1["ZY"]);
                    Glade.Text = Convert.ToString(r1["NJ"]);
                    Class.Text = Convert.ToString(r1["BB"]);
                    StudentCatogary.Text = Convert.ToString(r1["XSLB"]);
                    EntryTime.Text = Convert.ToString(r1["RXSJ"]);
                    XueZhi.Text = Convert.ToString(r1["XZ"]);
                    MingZhu.Text = Convert.ToString(r1["MZ"]);
                    JiGuan.Text = Convert.ToString(r1["JG"]);
                    ZhengZhiMM.Text = Convert.ToString(r1["ZZMM"]);
                    Birthdate.Text = Convert.ToString(r1["CSNY"]);
                    IDNumber.Text = Convert.ToString(r1["SFZH"]);
                    ExamineID.Text = Convert.ToString(r1["KSH"]);
                    ShengYuanD.Text = Convert.ToString(r1["SYD"]);
                    FamilyAddr.Text = Convert.ToString(r1["JTZZ"]);
                    NowFamAddr.Text = Convert.ToString(r1["XJTZZ"]);
                    PostalCode.Text = Convert.ToString(r1["YZBM"]);
                    DormAddr.Text = Convert.ToString(r1["SSDZ"]);
                    HomePhoneNum.Text = Convert.ToString(r1["JTDH"]);
                    DormPhoneNum.Text = Convert.ToString(r1["SSDH"]);
                    MobilePhoneNum.Text = Convert.ToString(r1["SJH"]);
                }
                r1.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
             }
        }
        
        //学生修改登录密码
        private void button21_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (UsedPwd.Text == "")
                {
                    LoadTips1.Text = "!!!请输入原密码";
                    LoadTips1.Visible = true;
                }
                else if (NewPwd.Text == "")
                {
                    LoadTips1.Text = "!!!请输入新密码";
                    LoadTips1.Visible = true;
                }
                else if (SureNewPwd.Text == "")
                {
                    LoadTips1.Text = "!!!请再次输入密码";
                    LoadTips1.Visible = true;
                }
                else if (NewPwd.Text != SureNewPwd.Text)
                {
                    LoadTips1.Text = "!!!新密码与密码确认不一致";
                    LoadTips1.Visible = true;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("select * from XX_YHXXB where SF=@StuStatus and YHM=@StuName and PWD=@UsedPwd", DBConnection.conn);
                    cmd.Parameters.Add("@StuStatus", SqlDbType.NVarChar).Value = Convert.ToString(Stuid.StuStatus);
                    cmd.Parameters.Add("@StuName", SqlDbType.NVarChar).Value = Convert.ToString(Stuid.StuID);
                    cmd.Parameters.Add("@UsedPwd", SqlDbType.NVarChar).Value = UsedPwd.Text;
                    SqlDataReader r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        r.Close();
                        SqlCommand cmd1 = new SqlCommand("update XX_YHXXB set PWD=@NewPwd where SF=@StuStatus and YHM=@StuName", DBConnection.conn);
                        cmd1.Parameters.Add("@NewPwd", SqlDbType.NVarChar).Value = NewPwd.Text;
                        cmd1.Parameters.Add("@StuStatus", SqlDbType.NVarChar).Value = Convert.ToString(Stuid.StuStatus);
                        cmd1.Parameters.Add("@StuName", SqlDbType.NVarChar).Value = Convert.ToString(Stuid.StuID);
                        cmd1.ExecuteNonQuery();
                        LoadTips1.Text = "密码修改成功！";
                        button20_Click(sender, e);
                        LoadTips1.Visible = true;
                    }
                    else
                    {
                        LoadTips1.Text = "原密码不正确，请重新输入！";
                        UsedPwd.Text = "";
                        LoadTips1.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }
        
        private void UsedPwd_TextChanged(object sender, EventArgs e)
        {
            LoadTips1.Visible = false;
        }

        private void NewPwd_TextChanged(object sender, EventArgs e)
        {
            LoadTips1.Visible = false;
        }

        private void SureNewPwd_TextChanged(object sender, EventArgs e)
        {
            LoadTips1.Visible = false;
        }
        
        //密码重置
        private void button20_Click(object sender, EventArgs e)
        {
            LoadTips1.Visible = false;
            UsedPwd.Text = "";
            NewPwd.Text = "";
            SureNewPwd.Text = "";
        }

        /*在DataGridView中显示出相应的数据*/
        private void dgvShow(string str, DataGridView dgv)
        {
            DataSet dataset = new DataSet();
            try
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(str, DBConnection.conn);
                dataAdapter.Fill(dataset, "Score");
                dgv.DataSource = dataset.Tables["Score"];
                BindingManagerBase bmb = this.BindingContext[dataset.Tables["Score"]];
                if (dgv.Rows.Count != 0)
                {
                    for (int i = 0; i < dgv.Rows.Count; i += 2)
                    {
                        dgv.Rows[i].DefaultCellStyle.BackColor = System.Drawing.Color.FloralWhite;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*查询相应学生的课程*/
        private void SelectCourse_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                string selectCourse;
                selectCourse = string.Format("select XX_KC.KCH as '课程号',KCM as '课程名',SKJS as'授课教师',XF as'学分',XQ as'学期'");
                selectCourse += string.Format(" from XX_KC,XX_DA,XX_XSKCB where XQ='{0}'and XH='{1}' and XX_KC.KCH=XX_XSKCB.KCH and XX_DA.ZY=XX_XSKCB.ZY and XX_DA.NJ=XX_XSKCB.NJ", comboBox2.Text, Stuid.StuID);
                dgvShow(selectCourse, dataGridView5);
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*查询相应学生的成绩并显示出来*/
        private void SelectScore()
        {
            try
            {
                DBConnection.conn.Open();
                string selectScore;
                selectScore = string.Format("select XX_KC.KCH as '课程号', KCM as '课程名',SKJS as '授课教师',XF as '学分', CJ as '成绩', XQ as '学期'");
                selectScore += string.Format(" from XX_KC,XX_CJ,XX_DA,XX_XSKCB where XX_CJ.XH='{0}' and XX_XSKCB.KCH=XX_CJ.KCH and XX_DA.XH='{0}' and ",Stuid.StuID);
                selectScore += string.Format("XX_XSKCB.ZY=XX_DA.ZY and XX_XSKCB.NJ=XX_DA.NJ and XX_KC.KCH=XX_CJ.KCH order by XQ DESC;");
                dgvShow(selectScore, dataGridView2); 
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*查询相应学生的学费、奖惩信息并显示出来*/
        private void SelectFeeRewPun()
        {
            try
            {
                DBConnection.conn.Open();
                string selectFRP;
                selectFRP = string.Format("select XX_DA.XH as '学号',XM as '姓名',XQ as '学期',XY as '学院',ZY as '专业',NJ as '年级',BB as '班别',YJF as '已缴费',QF as '欠费',JL as '奖励',CF as '处分'");
                selectFRP += string.Format(" from XX_DA,XX_XFJC where XX_DA.XH='{0}' and XX_XFJC.XH='{0}';", Stuid.StuID);
                dgvShow(selectFRP, dataGridView3);
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        /*校历查询*/
        private void SelectXL_Click(object sender, EventArgs e)
        {
            try
            {
                DBConnection.conn.Open();
                if (comboBox1.Text != "")
                {
                    LoadTips2.Visible = false;
                    string selectXL;
                    selectXL = string.Format("select ZS as '周数',MON as '星期一',TUES as '星期二',WED as '星期三', THURS as '星期四',FRI as '星期五',");
                    selectXL += string.Format("SAT as '星期六',SUN as '星期日',BZ as '备注' from XX_XL where XQ='{0}';", comboBox1.Text);
                    dgvShow(selectXL, dataGridView4);
                }
                else
                {
                    LoadTips2.Text = "学期不能为空!";
                    LoadTips2.Visible = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { DBConnection.conn.Close(); }
        }

        private void tabContorl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    break;
                case 2:
                    SelectScore();
                    break;
                case 3:
                    SelectFeeRewPun();
                    break;
            }
        }

        /*退出程序*/
        private void Exit(object sender, FormClosedEventArgs e)
        {
            this.Owner.Dispose();
        }
    }
}
