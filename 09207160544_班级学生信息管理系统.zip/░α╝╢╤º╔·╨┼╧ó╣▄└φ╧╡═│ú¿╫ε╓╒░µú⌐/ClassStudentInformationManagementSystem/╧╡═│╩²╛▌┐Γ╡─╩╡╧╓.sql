create table XX_DA
(XH varchar(30) primary key not null,
 XM varchar(10) not null,
 CYM varchar(10),
 SFZH varchar(50) not null,
 XB char(2) not null,
 CSNY varchar(10),
 ZZMM varchar(10),
 MZ varchar(10) not null,
 JG varchar(10) not null,
 SYD varchar(30) not null,
 XX varchar(30) not null,
 XY varchar(30) not null,
 ZY varchar(30) not null,
 NJ varchar(10) not null,
 BB varchar(10) not null,
 RXSJ varchar(10) not null,
 XSLB varchar(10) not null,
 XZ varchar(10) not null,
 KSH varchar(30) not null,
 JTZZ varchar(max) not null,
 XJTZZ varchar(max) not null,
 JTDH varchar(20) not null,
 YZBM varchar(10) not null,
 SSDZ varchar(20) not null,
 SSDH varchar(20),
 SJH varchar(20) not null);
 
 create table XX_KC
 (KCH varchar(10) primary key not null,
  KCM varchar(30) not null,
  SKJS varchar(10),
  XF int);
   
 create table XX_XSKCB
 (KCH varchar(10) not null,
  ZY varchar(30) not null,
  NJ varchar(10) not null,
  XQ varchar(30) not null,
  primary key(KCH,ZY,NJ,XQ));
  
   create table XX_CJ
   (XH varchar(30) not null,
    KCH varchar(10) not null,
    CJ int,
    primary key(KCH,XH),
    foreign key(XH) references XX_DA(XH),
    foreign key(KCH) references XX_KC(KCH));
 
 create table XX_YHXXB
 (YHM varchar(30) primary key not null,
  PWD varchar(20),
  SF varchar(10));
 
 create table XX_XFJC
 (XH varchar(30) not null,
  YJF int,
  QF int,
  JL varchar(max),
  CF varchar(max),
  XQ varchar(30) not null,
  primary key(XH,XQ),
  foreign key(XH) references XX_DA(XH));
  
  create table XX_XL
  (XQ varchar(30) not null,
   ZS varchar(10) not null,
   MON varchar(10),
   TUES varchar(10),
   WED varchar(10),
   THURS varchar(10),
   FRI varchar(10),
   SAT varchar(10),
   SUN varchar(10),
   BZ varchar(max),
   primary key(XQ,ZS));